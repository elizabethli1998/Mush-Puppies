package com.example.elizabethli.mushpuppiestest;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Button;
import java.util.ArrayList;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import com.example.elizabethli.mushpuppiestest.ExerciseDatabase.ExerciseDatabaseHelper;


public class CardioActivity extends AppCompatActivity {

    Button backButton;
    Button customButton1;
    private TextView mTextMessage;
    private static final String TAG = "CardioActivity";

    ExerciseDatabaseHelper mDatabaseHelper;

    ArrayList<String> selectedItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardio);
        mDatabaseHelper = new ExerciseDatabaseHelper(this);


        ListView checked = (ListView) findViewById(R.id.checkable_list);
        checked.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);


        final ArrayList<String> items = new ArrayList<String>();
        items.add("Walking (40 Minutes)");
        items.add("Cycling (40 Minutes)");
        items.add("Step Aerobics (40 Minutes)");
        items.add("Elliptical Machine (50 Minutes)");
        items.add("Kayaking (1 Hour)");
        items.add("Tai Chi (1 Hour)");
        items.add("Yoga (50 Minutes)");
        items.add("Pilates (50 Minutes)");
        items.add("Ballroom Dancing (50 minutes)");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.item_cardio_list, R.id.text_workout,items);
        checked.setAdapter(adapter);
        checked.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedItem = ((TextView)view).getText().toString();

                if(selectedItems.contains(selectedItem))
                {
                    selectedItems.remove(selectedItem);
                }
                else
                {
                    selectedItems.add(selectedItem);
                    AddData(selectedItem);

                }
            }
        });
        ListView checked2 = (ListView) findViewById(R.id.medium_intensity_list);
        checked2.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        String[] items2 = {"Swimming Laps (30 Minutes)", "Brisk Walking (30 Minutes)", "Tennis Doubles (30 Minutes)", "Biking Under 10 mph (30 Minutes)",
                "Volleyball (30 Minutes)", "Softball/Baseball (30 Minutes)", "Jogging (30 Minutes)"};
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, R.layout.item_cardio_list, R.id.text_workout,items2);
        checked2.setAdapter(adapter2);
        checked2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedItem = ((TextView)view).getText().toString();

                if(selectedItems.contains(selectedItem))
                {
                    selectedItems.remove(selectedItem); //This unchecks the item
                }
                else
                {
                    selectedItems.add(selectedItem);
                    AddData(selectedItem);

                }
            }
        });

        ListView checked3 = (ListView) findViewById(R.id.high_intensity_list);
        checked3.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        String[] items3 = {"Hiking (20 Minutes)", "Climbing Stairs (20 Minutes)", "Sprinting (20 Minutes)", "Jumping Rope (20 Minutes)",
        "Toe Touch (15 Reps)", "Walking Lunge (10 Reps/Leg)", "Butt Kick (25 Reps/Leg)", "High Knees (25 Reps/Leg)", "Trunk Twist (20 Reps/Side)"};
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, R.layout.item_cardio_list, R.id.text_workout,items3);
        checked3.setAdapter(adapter3);
        checked3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedItem = ((TextView)view).getText().toString();

                if(selectedItems.contains(selectedItem))
                {
                    selectedItems.remove(selectedItem); //This unchecks the item
                }
                else
                {
                    selectedItems.add(selectedItem);
                    AddData(selectedItem);

                }
            }
        });


        backButton = (Button) findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(CardioActivity.this, AddExerciseActivity.class);
                startActivity(addExerciseIntent);
                finish();
            }

        });

        //initialization for the bottom navigation stuff
        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);


    }

    public void AddData(String newEntry)
    {
        boolean insertData = mDatabaseHelper.addData(newEntry);

        if(insertData)
        {
            Toast.makeText(getApplicationContext(),"Updated Exercise List!",Toast.LENGTH_SHORT).show();

        }
    }



    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(CardioActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                case R.id.navigation_leaderboard:
                    mTextMessage.setText(R.string.title_leaderboard);
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(CardioActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                case R.id.navigation_groups:
                    mTextMessage.setText(R.string.title_groups);
                    return true;
                case R.id.navigation_friends:
                    mTextMessage.setText(R.string.title_friends);
                    return true;
            }
            return false;
        }
    };
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_mush_puppies, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}