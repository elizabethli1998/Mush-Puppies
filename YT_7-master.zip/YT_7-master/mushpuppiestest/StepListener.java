package com.example.elizabethli.mushpuppiestest;

/**
 * Created by meghnavaidya on 2/21/18.
 */

public interface StepListener {

    public void step(long timeNs);

}