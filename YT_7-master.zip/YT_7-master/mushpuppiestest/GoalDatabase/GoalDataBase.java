package com.example.elizabethli.mushpuppiestest.GoalDatabase;


import android.provider.BaseColumns;



public class GoalDataBase
{
    public static final String DB_NAME = "com.example.elizabethli.mushpuppiestest";
    public static final int DB_VERSION = 1;

    public class GoalEntry implements BaseColumns
    {
        public static final String TABLE = "goals";
        public static final String COL_TASK_TITLE = "title";
    }
}
