package com.example.elizabethli.mushpuppiestest.GoalDatabase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class GoalDatabaseHelper extends SQLiteOpenHelper {

        public GoalDatabaseHelper(Context context) {
            super(context, GoalDataBase.DB_NAME, null, GoalDataBase.DB_VERSION);
        }


        @Override
        public void onCreate(SQLiteDatabase db) {
            String createTable = "Create Table " + GoalDataBase.GoalEntry.TABLE + " ( " +
                    GoalDataBase.GoalEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    GoalDataBase.GoalEntry.COL_TASK_TITLE + " TEXT NOT NULL);";
            db.execSQL(createTable);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + GoalDataBase.GoalEntry.TABLE);
            onCreate(db);
        }

    }

