package com.example.elizabethli.mushpuppiestest;

import android.app.ProgressDialog;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity implements SensorEventListener, StepListener, View.OnClickListener{

    //this is the default textview from the template for the bottom navigation activity
    //I left it in so you can still see how the default navigation activity works
    private Button btnUpdateSettings;
    private Button btnLogOut;

    private TextView userName;
    private TextView firstName;
    private TextView lastName;
    private TextView feet;
    private TextView inches;
    private TextView age;
    private TextView weight;
    private TextView totalSteps;

    private TextView TvSteps;
    private StepDetector simpleStepDetector;
    private int numSteps;

    private TextView mTextMessage;
    private String TAG = ProfileActivity.class.getSimpleName();
    private Button btnUpdate;
    private TextView msgResponse;
    private ProgressDialog pDialog;
    private String jsonResponse;
    private String url = "http://IP:8080/";

    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);




        btnUpdate = (Button) findViewById(R.id.btnUpdateMe);

        msgResponse = (TextView) findViewById(R.id.msgResponse);

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);

        btnUpdate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // making json array request
                makeJsonArryReq();
            }
        });

        //initialization for the bottom navigation stuff
        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);

        btnUpdateSettings = (Button) findViewById(R.id.btnUpdate);
        btnUpdateSettings.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent updateIntent = new Intent(ProfileActivity.this, UpdateActivity.class);
                startActivity(updateIntent);
                finish();
            }
        });

        btnLogOut = (Button) findViewById(R.id.btnLogOut);

        userName = (TextView) findViewById(R.id.txtUser);
        firstName = (TextView) findViewById(R.id.txtFirst);
        lastName = (TextView) findViewById(R.id.txtLast);
        feet = (TextView) findViewById(R.id.txtFeet);
        inches = (TextView) findViewById(R.id.txtInch);
        age = (TextView) findViewById(R.id.txtYears);
        weight = (TextView) findViewById(R.id.txtPounds);
        totalSteps = (TextView) findViewById(R.id.txtSteps);






        //for each textview:

        //userName.setText(<value recieved from json>);
        //firstName.setText(<value recieved from json>);
        //lastName.setText(<value recieved from json>);
        //feet.setText(<value recieved from json>);
        //inches.setText(<value recieved from json>);
        //age.setText(<value recieved from json>);
        //weight.setText(<value recieved from json>);
        //totalSteps.setText(<value recieved from json>);


        // Get an instance of the SensorManager
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        assert sensorManager != null;
        Sensor accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        simpleStepDetector = new StepDetector();
        simpleStepDetector.registerListener(this);
        TvSteps = findViewById(R.id.tv_steps);
        numSteps = 0;
        TvSteps.setText("0");
        sensorManager.registerListener(ProfileActivity.this, accel, SensorManager.SENSOR_DELAY_FASTEST);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    mTextMessage.setText(R.string.title_leaderboard);
                    return true;
                case R.id.navigation_leaderboard:
                    Intent profileIntent = new Intent(ProfileActivity.this, LeaderboardActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(ProfileActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                    return true;
                case R.id.navigation_friends:
                    Intent friendsIntent = new Intent(ProfileActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    finish();
                    return true;
                case R.id.navigation_groups:
                    Intent groupsIntent = new Intent(ProfileActivity.this, GroupsActivity.class);
                    startActivity(groupsIntent);
                    finish();
                    return true;
            }
            return false;
        }
    };



    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            simpleStepDetector.updateAccel(
                    event.timestamp, event.values[0], event.values[1], event.values[2]);
        }
    }

    @Override
    public void step(long timeNs) {
        numSteps++;
        TvSteps.setText(String.valueOf(numSteps));
    }

    @Override
    public void onClick(View view) {

    }

    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.hide();
    }

    private void makeJsonArryReq() {
        showProgressDialog();
        JsonArrayRequest req = new JsonArrayRequest(/*Const.URL_JSON_ARRAY*/ url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {


                        Log.d(TAG, response.toString());
                        try {
                            jsonResponse = "";
                            for(int i = 0 ; i < response.length();i++) {
                                JSONObject user = (JSONObject) response.get(i);
                                int id = user.getInt("id");
                                String username = user.getString("username");
                                int steps = user.getInt("steps");
                                boolean something = user.getBoolean("new");
                                String firstName = user.getString("firstName");
                                String lastName = user.getString("lastName");



                                jsonResponse += "id: " + id + "\n\n";
                                jsonResponse += "username: " + username + "\n\n";
                                jsonResponse += "steps: " + steps + "\n\n";
                                jsonResponse += "lastName: " + lastName + "\n\n\n";
                                jsonResponse += "firstName: " + firstName + "\n\n\n";

                            /*jsonResponse = "";
                            for (int i = 0; i < response.length(); i++) {

                                JSONObject person = (JSONObject) response
                                        .get(i);

                                String name = person.getString("name");
                                String email = person.getString("email");
                                JSONObject phone = person
                                        .getJSONObject("phone");
                                String home = phone.getString("home");
                                String mobile = phone.getString("mobile");

                                jsonResponse += "Name: " + name + "\n\n";
                                jsonResponse += "Email: " + email + "\n\n";
                                jsonResponse += "Home: " + home + "\n\n";
                                jsonResponse += "Mobile: " + mobile + "\n\n\n"; */


                            }
                            msgResponse.setText(jsonResponse);


                        }
                        catch(JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),
                                    "Error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();

                        }




                        hideProgressDialog();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                hideProgressDialog();
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(req);

        // Cancelling request
        // ApplicationController.getInstance().getRequestQueue().cancelAll(tag_json_arry);
    }

    private void postJsonObj() {
        showProgressDialog();
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.hide();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.hide();
            }
        }) {
           @Override
            protected Map<String, String> getParams() {
               Map<String, String> params = new HashMap<String, String>();
               params.put("id", "23425");
               params.put("username", "peteboy");
               params.put("name", "Pete");



               return params;
           }

        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);

    }
}
