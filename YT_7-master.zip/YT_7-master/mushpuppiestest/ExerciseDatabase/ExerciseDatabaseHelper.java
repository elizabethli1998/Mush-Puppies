package com.example.elizabethli.mushpuppiestest.ExerciseDatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.database.Cursor;




public class ExerciseDatabaseHelper extends SQLiteOpenHelper
{
    private static final String TAG = "ExerciseDatabaseHelper";
    private static final String TABLE_NAME = "exercise_table";
    private static final String COL1 = "ID";
    private static final String COL2 = "exercise";
    private SQLiteDatabase db;

    public ExerciseDatabaseHelper(Context context)
    {
        super(context, TABLE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String createTable = "Create Table " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL2 + " TEXT)";
        db.execSQL(createTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1)
    {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addData(String item)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, item);
        Log.d(TAG, "addData: Adding " + item + " to " + TABLE_NAME);
        long result = db.insert(TABLE_NAME, null, contentValues);
        if(result == -1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    public boolean update(String item)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        if (db == null) {
            return false;
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, item);
        db.update(TABLE_NAME, contentValues, COL2 + " = ?", new String[] {item} );
        return true;


    }

    public void deleteAll()
    {
        SQLiteDatabase db = this.getWritableDatabase();
       //db.delete(TABLE_NAME,COL2 + "=?", new String[] {String.valueOf(id)});
        db.delete(TABLE_NAME, null, null);
       db.close();


    }
    public void deleteData (long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, "exercise = ?",new String[] {String.valueOf(id)});
    }


    public Cursor getData()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(query, null);
        return data;
    }


}
