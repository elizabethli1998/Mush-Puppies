package com.example.elizabethli.mushpuppiestest;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.RadioButton;
import android.widget.RadioGroup;


public class CaloriesActivity extends AppCompatActivity {

    //comment
    TextView totalTextView;
    EditText weightTxt;
    EditText durationTxt;
    RadioGroup rg;
    double milesPerHour;

    //this is the default textview from the template for the bottom navigation activity
    //I left it in so you can still see how the default navigation activity works
    private TextView mTextMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calories);

        //initialization for the bottom navigation stuff
        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        mTextMessage.setText(R.string.title_calories);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);
    }

    public void onRadioButtonClicked(View v)
    {
        totalTextView = (TextView) findViewById(R.id.totalTextView);
        weightTxt = (EditText) findViewById(R.id.weightTxt); //btw I changed these ids to id's in the xml files, but they probs don't need to be here
        durationTxt = (EditText) findViewById(R.id.durationTxt);

        Button calcBtn = (Button) findViewById(R.id.calcBtn);
        rg = (RadioGroup) findViewById(R.id.radioGroup);
        RadioButton walkButton = (RadioButton)findViewById(R.id.walkBtn);
        RadioButton jogButton = (RadioButton)findViewById(R.id.jogBtn);
        RadioButton runButton = (RadioButton)findViewById(R.id.runBtn);
        boolean checked = ((RadioButton) v).isChecked();


        switch(v.getId()){

            case R.id.walkBtn:
                if(checked)
                milesPerHour = 2;
                break;
            case R.id.jogBtn:
                if(checked)
                milesPerHour = 4;
                break;
            case R.id.runBtn:
                if(checked)
                milesPerHour = 5;
                break;

        }


        calcBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                double weight = Double.parseDouble(weightTxt.getText().toString());

                double duration = Double.parseDouble(durationTxt.getText().toString());
                double total = 0.53 * weight * milesPerHour * (duration/60);
                totalTextView.setText(Double.toString(total));
            }

        });
    }

    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(CaloriesActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_leaderboard:
                    Intent leaderboardIntent = new Intent(CaloriesActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    finish();
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(CaloriesActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                    return true;
                case R.id.navigation_friends:
                    Intent friendsIntent = new Intent(CaloriesActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    finish();
                    return true;
                case R.id.navigation_groups:
                    Intent groupsIntent = new Intent(CaloriesActivity.this, GroupsActivity.class);
                    startActivity(groupsIntent);
                    finish();
                    return true;
            }
            return false;
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_mush_puppies, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
