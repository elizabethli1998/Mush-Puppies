package com.example.elizabethli.mushpuppiestest;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.CalendarView;
import android.widget.Toast;
import android.view.Gravity;
import android.widget.ListView;
import android.util.Log;
import android.database.Cursor;
import java.util.ArrayList;

import android.widget.ListAdapter;
import com.example.elizabethli.mushpuppiestest.ExerciseDatabase.ExerciseDatabaseHelper;


public class HomeActivity extends AppCompatActivity {

    //this is the default textview from the template for the bottom navigation activity
    //I left it in so you can still see how the default navigation activity works
    private TextView mTextMessage;
    private Button caloriesButton;
    private Button addExerciseButton;
    private Button myGoalsButton;
    private Button deleteButton;
    private Button addCustomButton;
    CalendarView calendarView;
    ExerciseDatabaseHelper mDatabaseHelper;
    private ListView listView;
    private static final String TAG = "HomeActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //initialization for the bottom navigation stuff
        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        listView = (ListView) findViewById(R.id.listView);
        mDatabaseHelper = new ExerciseDatabaseHelper(this);
        populateListView();
         listViewItemClick();

        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);

        calendarView = (CalendarView) findViewById(R.id.calendarView);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                Toast toast = Toast.makeText(getApplicationContext(), month + "/" + dayOfMonth + "/" + year, Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.BOTTOM, 0, 0);
                toast.show();

            }
        });

        caloriesButton = (Button) findViewById(R.id.caloriesButton);
        caloriesButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent caloriesIntent = new Intent(HomeActivity.this, CaloriesActivity.class);
                caloriesIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                caloriesIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                caloriesIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(caloriesIntent);
            }

        });
        addExerciseButton = (Button) findViewById(R.id.addExerciseButton);
        addExerciseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(HomeActivity.this, AddExerciseActivity.class);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(addExerciseIntent);
            }

        });
        myGoalsButton = (Button) findViewById(R.id.myGoalsButton);
        myGoalsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent myGoalsIntent = new Intent(HomeActivity.this, GoalActivity.class);
                myGoalsIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                myGoalsIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                myGoalsIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(myGoalsIntent);

            }

        });
        deleteButton = (Button) findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                mDatabaseHelper.deleteAll();
                populateListView();
            }
        });
        addCustomButton  = (Button)findViewById(R.id.addCustomButton);
        addCustomButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                final EditText exerciseEditText = new EditText(HomeActivity.this);
                AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
                builder.setTitle("Customize Your Workout!");
                builder.setMessage("Enter your own custom workout!");
                builder.setView(exerciseEditText);
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch(which){
                            case DialogInterface.BUTTON_POSITIVE:
                                // User clicked the Add button
                                String addedItem = (exerciseEditText.getText().toString());
                                mDatabaseHelper.addData(addedItem);
                                populateListView();

                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                // User clicked the Cancel button
                                break;
                        }
                    }
                };

                // Set the alert dialog add button click listener
                builder.setPositiveButton("Add", dialogClickListener);

                // Set the alert dialog cancel button click listener
                builder.setNegativeButton("Cancel",dialogClickListener);

                AlertDialog dialog = builder.create();
                builder.setView(v);
                dialog.show();
            }
        });
    }

    private void populateListView()
    {
            Log.d(TAG, "populateListView: Displaying data in the ListView.");
            Cursor data = mDatabaseHelper.getData();
            ArrayList<String> listData = new ArrayList<>();
            while(data.moveToNext())
            {
                listData.add(data.getString(1));
            }
           ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
           listView.setAdapter(adapter);

    }


   private void listViewItemClick() {
        ListView myList = (ListView) findViewById(R.id.listView);

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mDatabaseHelper.deleteData(id);
                populateListView();
            }
        });
    }

    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(HomeActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_leaderboard:
                    Intent leaderboardIntent = new Intent(HomeActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    finish();
                    return true;
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_friends:
                    Intent friendsIntent = new Intent(HomeActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    finish();
                    return true;
                case R.id.navigation_groups:
                    Intent groupsIntent = new Intent(HomeActivity.this, GroupsActivity.class);
                    startActivity(groupsIntent);
                    finish();
                    return true;
            }
            return false;
        }
    };

}
