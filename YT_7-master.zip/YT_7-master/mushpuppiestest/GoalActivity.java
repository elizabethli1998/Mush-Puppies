package com.example.elizabethli.mushpuppiestest;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Button;


import com.example.elizabethli.mushpuppiestest.GoalDatabase.GoalDataBase;
import com.example.elizabethli.mushpuppiestest.GoalDatabase.GoalDatabaseHelper;
import java.util.ArrayList;


public class GoalActivity extends AppCompatActivity
{
    private static final String TAG = "GoalActivity";
    private GoalDatabaseHelper mHelper;

    private ListView goalListView;
    private ArrayAdapter<String> mAdapter;
    Button backButton;
    Button doneButton;
    Button updateButton;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        mHelper = new GoalDatabaseHelper(this);
        goalListView = (ListView) findViewById(R.id.list_todo);
        updateUI();

        backButton = (Button) findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(GoalActivity.this, HomeActivity.class);
                startActivity(addExerciseIntent);
                finish();
            }

        });

        doneButton = (Button) findViewById(R.id.doneButton);
        updateButton = (Button) findViewById(R.id.updateButton);


    }
    private void storeColor(int color)
    {
        SharedPreferences mSharedPreferences = getSharedPreferences("goalTitleColor", MODE_PRIVATE);
        SharedPreferences.Editor mEditor = mSharedPreferences.edit();
        mEditor.putInt("color", color);
        mEditor.apply();
    }
    private int getColor()
    {
        SharedPreferences mSharedPreferences = getSharedPreferences("goalTitleColor", MODE_PRIVATE);
        int selectedColor = mSharedPreferences.getInt("color",  getResources().getColor(R.color.colorTeal));
        return selectedColor;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_mush_puppies, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add_goal:
                final EditText taskEditText = new EditText(this);
                AlertDialog dialog = new AlertDialog.Builder(this)
                        .setTitle("New Goal")
                        .setMessage("Add a new goal")
                        .setView(taskEditText)
                        .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogue, int which) {
                                String task = String.valueOf(taskEditText.getText());
                                SQLiteDatabase db = mHelper.getWritableDatabase();
                                ContentValues values = new ContentValues();
                                values.put(GoalDataBase.GoalEntry.COL_TASK_TITLE, task);
                                db.insertWithOnConflict(GoalDataBase.GoalEntry.TABLE, null, values, SQLiteDatabase.CONFLICT_REPLACE);
                                db.close();
                                updateUI();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create();
                dialog.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateUI() {
        ArrayList<String> taskList = new ArrayList<>();
        SQLiteDatabase db = mHelper.getReadableDatabase();
        Cursor cursor = db.query(GoalDataBase.GoalEntry.TABLE,
                new String[] {GoalDataBase.GoalEntry.COL_TASK_TITLE}, null, null, null, null, null);

        while (cursor.moveToNext()) {
            int index = cursor.getColumnIndex(GoalDataBase.GoalEntry.COL_TASK_TITLE);
            taskList.add(cursor.getString(index));
        }

        if (mAdapter == null) {
            mAdapter = new ArrayAdapter<String>(this, R.layout.item_goal, R.id.goal_title, taskList);
            goalListView.setAdapter(mAdapter);

        } else {
            mAdapter.clear();
            mAdapter.addAll(taskList);
            mAdapter.notifyDataSetChanged();
        }

        cursor.close();
        db.close();
    }

    public void deleteTask(View view) {
        View parent = (View) view.getParent();
        TextView goalTextView = (TextView) parent.findViewById(R.id.goal_title);
        String task = String.valueOf(goalTextView.getText());
        SQLiteDatabase db = mHelper.getWritableDatabase();
        db.delete(GoalDataBase.GoalEntry.TABLE, GoalDataBase.GoalEntry.COL_TASK_TITLE + " = ?", new String[] {task});
        db.close();
        updateUI();

    }

  public void finishTask(View view)
  {
      View parent = (View) view.getParent();
      TextView goalTitle = (TextView) parent.findViewById(R.id.goal_title);
      String  task = String.valueOf(goalTitle.getText());
      SQLiteDatabase db = mHelper.getWritableDatabase();
      ContentValues values = new ContentValues();
      if(!task.contains("Done")) {
          values.put(GoalDataBase.GoalEntry.COL_TASK_TITLE, task + ":" + " " + "Done");
          db.delete(GoalDataBase.GoalEntry.TABLE, GoalDataBase.GoalEntry.COL_TASK_TITLE + " = ?", new String[]{task});
          db.replace(GoalDataBase.GoalEntry.TABLE, GoalDataBase.GoalEntry.COL_TASK_TITLE, values);
          db.close();
          updateUI();
      }
      else
      {
          db.close();
      }

  }
    public void updateTask(View view)
    {
        View parent = (View) view.getParent();
        final TextView goalTitle = (TextView) parent.findViewById(R.id.goal_title);
        final EditText  taskEditText = new EditText(this);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Update Goal")
                .setMessage("Update your current goal")
                .setView(taskEditText)
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogue, int which) {
                        String previousTask = String.valueOf(goalTitle.getText());
                        String task = String.valueOf(taskEditText.getText());
                        SQLiteDatabase db = mHelper.getWritableDatabase();
                        ContentValues values = new ContentValues();
                        values.put(GoalDataBase.GoalEntry.COL_TASK_TITLE, task);
                        db.delete(GoalDataBase.GoalEntry.TABLE, GoalDataBase.GoalEntry.COL_TASK_TITLE + " = ?", new String[]{previousTask});
                        db.replace(GoalDataBase.GoalEntry.TABLE, GoalDataBase.GoalEntry.COL_TASK_TITLE, values);
                        db.close();
                        updateUI();
                    }
                })
                .setNegativeButton("Cancel", null)
                .create();
        dialog.show();

    }


}
