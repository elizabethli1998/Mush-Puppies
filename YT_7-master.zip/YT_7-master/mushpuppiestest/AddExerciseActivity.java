package com.example.elizabethli.mushpuppiestest;


import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class AddExerciseActivity extends AppCompatActivity
{

    private TextView mTextMessage;
    Button backButton;
    Button cardioButton;
    Button liftingButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_exercise);

        //initialization for the bottom navigation stuff
        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);

        backButton = (Button) findViewById(R.id.backButton);
        cardioButton = (Button) findViewById(R.id.cardioButton);
        liftingButton = (Button) findViewById(R.id.liftingButton);


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(AddExerciseActivity.this, HomeActivity.class);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(addExerciseIntent);
            }

        });

        cardioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(AddExerciseActivity.this, CardioActivity.class);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(addExerciseIntent);
            }

        });

        liftingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(AddExerciseActivity.this, LiftingActivity.class);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(addExerciseIntent);
            }

        });
    }

    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(AddExerciseActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                case R.id.navigation_leaderboard:
                    mTextMessage.setText(R.string.title_leaderboard);
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(AddExerciseActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                case R.id.navigation_groups:
                    mTextMessage.setText(R.string.title_groups);
                    return true;
                case R.id.navigation_friends:
                    mTextMessage.setText(R.string.title_friends);
                    return true;
            }
            return false;
        }
    };
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_mush_puppies, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
