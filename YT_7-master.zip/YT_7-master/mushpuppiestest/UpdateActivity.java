package com.example.elizabethli.mushpuppiestest;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class UpdateActivity extends AppCompatActivity{

    private Button btnCancel;
    private Button btnSave;

    private EditText userName;
    private EditText firstName;
    private EditText lastName;
    private EditText feet;
    private EditText inches;
    private EditText age;
    private EditText weight;
    private EditText totalSteps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);

        userName = (EditText) findViewById(R.id.edtUsername);
        firstName = (EditText) findViewById(R.id.edtFirstName);
        lastName = (EditText) findViewById(R.id.edtLastName);
        feet = (EditText) findViewById(R.id.edtFeet);
        inches = (EditText) findViewById(R.id.edtInch);
        age = (EditText) findViewById(R.id.edtYears);
        weight = (EditText) findViewById(R.id.edtPounds);

        //this is where the json request needs to happen I think



        //for each EditText:

        //userName.setText(<value recieved from json>);
        //firstName.setText(<value recieved from json>);
        //lastName.setText(<value recieved from json>);
        //feet.setText(<value recieved from json>);
        //inches.setText(<value recieved from json>);
        //age.setText(<value recieved from json>);
        //weight.setText(<value recieved from json>);
        //totalSteps.setText(<value recieved from json>);

        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent cancelIntent = new Intent(UpdateActivity.this, ProfileActivity.class);
                startActivity(cancelIntent);
                finish();
            }
        });

        btnSave = (Button) findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                //Saves each value in edit texts to the database


                Intent saveIntent = new Intent(UpdateActivity.this, ProfileActivity.class);
                startActivity(saveIntent);
                finish();
            }
        });
    }

    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(UpdateActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_leaderboard:
                    Intent leaderboardIntent = new Intent(UpdateActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    finish();
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(UpdateActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                    return true;
                case R.id.navigation_friends:
                    Intent friendsIntent = new Intent(UpdateActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    finish();
                    return true;
                case R.id.navigation_groups:
                    Intent groupsIntent = new Intent(UpdateActivity.this, GroupsActivity.class);
                    startActivity(groupsIntent);
                    finish();
                    return true;
            }
            return false;
        }
    };
}
