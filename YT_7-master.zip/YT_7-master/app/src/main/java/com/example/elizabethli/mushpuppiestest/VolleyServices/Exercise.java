package com.example.elizabethli.mushpuppiestest.VolleyServices;

import java.sql.Date;

/**
 * Created by Justin on 4/20/18.
 */

public class Exercise {

    public Exercise() {

    }

    public Exercise(int uid, int exerciseId, String date) {
        super();
        this.uid = uid;
        this.exerciseId = exerciseId;
        this.date = date;
    }


    public Exercise(int id, int uid, int androidId, String date) {
        this.exerciseId = id;
        this.uid = uid;
        this.androidId = androidId;
        this.date = date;
    }

    /**
     * id for the exercise table.
     */
    private int exerciseId;

    /**
     * This is the user's id. This id is a foreign key.
     */

    private int uid;

    /**
     * Variable for name of exercise. Also, this is showing the name of the exercise
     * table
     */

    private int androidId;

    /**
     * this is the date the the user completed the exercise
     */

    private String date;

    public int getExerciseId() {
        return exerciseId;
    }


    public int getUid() {
        return uid;
    }


    public int getAndroidId() {
        return androidId;
    }


    public String getDate() {
        return date;
    }


}
