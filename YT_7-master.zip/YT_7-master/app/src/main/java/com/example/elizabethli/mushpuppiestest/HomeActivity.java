package com.example.elizabethli.mushpuppiestest;

/**
 * @author Elizabeth Li, Justin Lee, Meghna Vaidya
 * This Activity is where most of the magic happens. The Home Activity connects many of the activities together
 * and it's the first screen that appears when the User appears on the app. Here, the User can navigate to the AddExercise
 * Activity, Calories Activity, Goals Activity, and displays the Calendar Feature/ information that involves anything Daily, including
 * Daily Calories Burned and Exercises that are planned for the day.
 * It also shows the amount of daily steps the User has taken in a day and the amount of cumulative Calories burned, along with the
 * Exercise List.
 */

import android.app.AlarmManager;
import android.app.ListActivity;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.CalendarView;
import android.widget.Toast;
import android.view.Gravity;
import android.util.Log;
import android.database.Cursor;
import java.util.ArrayList;
import android.widget.ListAdapter;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.elizabethli.mushpuppiestest.ExerciseDatabase.ExerciseDatabaseHelper;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.example.elizabethli.mushpuppiestest.CalorieDatabase.CalorieDatabaseHelper;
import com.example.elizabethli.mushpuppiestest.CalorieDatabase.DailyCalorieDatabaseHelper;
import com.example.elizabethli.mushpuppiestest.NotificationHelper;
import com.example.elizabethli.mushpuppiestest.VolleyServices.Exercise;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * This class provides navigation for Goals, Exercises, Calories, and provides Daily information in the Calendar
 * such as Calories Burned for each day and exercises planned for each day. It also provides the cumulative calories burned
 * and steps taken for the day. This Activity is the default screen that pops up when you open up the app.
 */

public class HomeActivity extends AppCompatActivity {


    private static final int NOTI_PRIMARY1 = 1100;
    private static final int NOTI_PRIMARY2 = 1101;
    private static final int NOTI_PRIMARY3 = 1102;
    private static final int NOTI_PRIMARY4 = 1103;
    //this is the default textview from the template for the bottom navigation activity
    //I left it in so you can still see how the default navigation activity works
    private int total;

    CalorieDatabaseHelper myDb;
    DailyCalorieDatabaseHelper myDb1;
    private NotificationHelper noti;
    private TextView totalCalories;
    private TextView totalCaloriesView;
    private TextView mTextMessage;
    private TextView dailySteps;
    private Button caloriesButton;
    private Button addExerciseButton;
    private Button myGoalsButton;
    private Button deleteButton;
    private ProgressDialog pDialog;
    String selectedDate;
    CalendarView calendarView;
    ExerciseDatabaseHelper mDatabaseHelper;
    NotificationSettingsActivity a;
    private ListView exerciseMenu;
    private ListView listView;
    private static final String TAG = "HomeActivity";
    String newResponse = "";
    ArrayAdapter<String> adapter;
    ArrayList<String> listItems=new ArrayList<String>();
    String exercises;
    Toast toast1;
    String dailyCalorieLog = "";
    String deleteUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/deleteexerciseuid";
    String uiurl = "http://proj-309-yt-7.cs.iastate.edu:8080/exercisesonlogin/" + Global.getId();
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";
    int userid = Global.getId();
    int eindex;
    ArrayList<Exercise> userExercise = Global.getUserExercises();
    ArrayList<Exercise> tempExercises = new ArrayList<>();

    private  String [] allExercises = Global.getallExercises();

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        setContentView(R.layout.activity_home);


        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);



        //initialization for the bo
        // ttom navigation stuff
       // mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        dailySteps = (TextView) findViewById(R.id.dailySteps);
        dailySteps.setText(Integer.toString(Global.getDailySteps()));


        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        exerciseMenu= (ListView) findViewById(R.id.listView);
        totalCalories = (TextView) findViewById(R.id.totalCalories);
        totalCaloriesView = (TextView) findViewById(R.id.totalCaloriesView);
        listView = (ListView) findViewById(R.id.listView);
        mDatabaseHelper = new ExerciseDatabaseHelper(this);
        myDb = new CalorieDatabaseHelper(this);
        myDb1 = new DailyCalorieDatabaseHelper(this);

        noti = new NotificationHelper(this);
        //Notification things
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {

            @Override
            public void run() {
                sendNotification(NOTI_PRIMARY1, "Reminder:");
                sendNotification(NOTI_PRIMARY2, "Reminder");
            }

        }, 1000L);

        scheduleAlarm();
        populateListView();
        listViewItemClick();


        updateUI();
          //makeJsonArryReq();
        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);

        calendarView = (CalendarView) findViewById(R.id.calendarView);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {

                month = month + 1;
                selectedDate = month + "-" + dayOfMonth + "-" + year;

                if(month < 10 && dayOfMonth < 10)
                {
                    selectedDate = "0" + month + "-" + "0" + dayOfMonth + "-" + year;
                }
                else if(month > 9 && dayOfMonth < 10)
                {
                    selectedDate = month + "-" + "0" + dayOfMonth + "-" + year;
                }
                else if(month < 10 && dayOfMonth > 9)
                {
                    selectedDate = "0" + month + "-" + dayOfMonth + "-" + year;
                }
                    compareDates();


             /*   Cursor data = mDatabaseHelper.getData();
                exercises = "";

               while(data.moveToNext())
                {
                   if(data.getString(1).contains(selectedDate))
                   {
                        exercises += data.getString(1) + "\n";
                   }
                }

                if(!exercises.equals(""))
                {
                    toast1 = Toast.makeText(getApplicationContext(), exercises, Toast.LENGTH_SHORT);
                    toast1.show();
                } */
                Cursor data1 = myDb1.getData();
                while(data1.moveToNext())
                {
                     if(data1.getString(1).contains(selectedDate))
                     {
                        dailyCalorieLog += data1.getString(1) + "\n";
                     }
                }
                if(!dailyCalorieLog.equals(""))
                {
                    Toast toast2 = Toast.makeText(getApplicationContext(), dailyCalorieLog, Toast.LENGTH_SHORT);
                    toast2.setGravity(Gravity.TOP, 0, 0);
                    toast2.show();

                }
                if(dailyCalorieLog.equals("")) {
                    Handler mHandler = new Handler();
                    mHandler.postDelayed(new Runnable() {

                        @Override
                        public void run() {
                            sendNotification(NOTI_PRIMARY3, "Reminder ");
                        }

                    }, 1000L);

                }
/*              if(exercises.equals(""))
                {
                    Handler mHandler = new Handler();
                    mHandler.postDelayed(new Runnable() {

                        @Override
                        public void run() {
                            sendNotification(NOTI_PRIMARY4, "Reminder ");
                        }

                    }, 1000L);
                }*/

            }

        });

        caloriesButton = (Button) findViewById(R.id.caloriesButton);
        caloriesButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent caloriesIntent = new Intent(HomeActivity.this, CaloriesActivity.class);
                caloriesIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                caloriesIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                caloriesIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(caloriesIntent);

            }

        });
        addExerciseButton = (Button) findViewById(R.id.addExerciseButton);
        addExerciseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(HomeActivity.this, AddExerciseActivity.class);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(addExerciseIntent);
            }

        });
        myGoalsButton = (Button) findViewById(R.id.myGoalsButton);
        myGoalsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent myGoalsIntent = new Intent(HomeActivity.this, GoalActivity.class);
                myGoalsIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                myGoalsIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                myGoalsIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(myGoalsIntent);

            }

        });
        deleteButton = (Button) findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                deleteExercises();
                userExercise = Global.getUserExercises();
                updateUI();
                recreate();
            }
        });
       /* addCustomButton  = (Button)findViewById(R.id.addCustomButton);
        addCustomButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                final EditText exerciseEditText = new EditText(HomeActivity.this);
                AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
                builder.setTitle("Customize Your Workout!");
                builder.setMessage("Enter your own custom workout!");
                builder.setView(exerciseEditText);
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch(which){
                            case DialogInterface.BUTTON_POSITIVE:
                                // User clicked the Add button
                                String addedItem = (exerciseEditText.getText().toString());
                                mDatabaseHelper.addData(addedItem);
                                populateListView();

                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                // User clicked the Cancel button
                                break;
                        }
                    }
                };

                // Set the alert dialog add button click listener
                builder.setPositiveButton("Add", dialogClickListener);

                // Set the alert dialog cancel button click listener
                builder.setNegativeButton("Cancel",dialogClickListener);

                AlertDialog dialog = builder.create();
                builder.setView(v);
                dialog.show();
            }
        });
*/


    }

    private void updateUserExercises() {
        showProgressDialog();
        JsonArrayRequest req = new JsonArrayRequest(uiurl,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {


                        Log.d(TAG, response.toString());
                        try {

                            for(int i = 0; i < response.length(); i++) {
                                JSONObject temp = (JSONObject)response.get(i);
                                int uid = temp.getInt("uid");
                                int exerciseId = temp.getInt("androidId");
                                String date = temp.getString("date");

                                Exercise exercise = new Exercise(uid, exerciseId, date);
                                tempExercises.add(exercise);

                            }

                            Global.setUserExercises(tempExercises);







                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),
                                    "Error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();

                        }


                        hideProgressDialog();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                hideProgressDialog();
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(req);
    }


    private void updateUI() {

        updateUserExercises();
        listItems = new ArrayList<>();

        adapter=new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                listItems);
        exerciseMenu.setAdapter(adapter);
        userExercise = Global.getUserExercises();
        for (int i = 0; i < userExercise.size(); i++) {

            int eindex = userExercise.get(i).getExerciseId();
            String date = userExercise.get(i).getDate();

            listItems.add(allExercises[eindex] + "\n" + "Day: " + date);
            //newResponse += "Exercise #" + (i+1) + " " + allExercises[eindex] + "\n\n";
        }

        adapter.notifyDataSetChanged();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void sendNotification(int id, String title) {
        Notification.Builder nb = null;
        switch (id) {
            case NOTI_PRIMARY1:
                nb = noti.getNotification1(title, "Quit staring at Instagram and go exercise already!");
                break;
            case NOTI_PRIMARY2:
                nb = noti.getNotification1(title, "If you have 0 steps for today, I've got bad news for you, buddy");
                break;
            case NOTI_PRIMARY3:
                nb = noti.getNotification1(title, "No calories burned for this day! Someone is slacking!");
                break;
            case NOTI_PRIMARY4:
                nb = noti.getNotification1(title, "No exercises planned for this day! Seriously?");
                break;

        }
        if (nb != null) {
            noti.notify(id, nb);
        }
    }

    private void deleteExercises() {
        showProgressDialog();


        Map<String, Object> params = new HashMap<String, Object>();
        params.put("uid", Global.getId());


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, deleteUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());

                        pDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();

            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);

    }



    /**
     * A notifier that reminds the User to do their daily exercising, scheduled to remind the User every 24 hours with a message.
     */

    public void scheduleAlarm()
    {

        // time at which alarm will be scheduled here alarm is scheduled at 1 day from current time,
        // we fetch  the current time in milliseconds and added 1 day time
        // i.e. 24*60*60*1000= 86,400,000   milliseconds in a day

        Long time = new GregorianCalendar().getTimeInMillis()+ 24*60*60*1000;

        Intent intentAlarm = new Intent(this, NotifyService.class);

        // create the object
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        //set the alarm for particular time
        alarmManager.set(AlarmManager.RTC_WAKEUP,time, PendingIntent.getBroadcast(this,1,  intentAlarm, PendingIntent.FLAG_UPDATE_CURRENT));
        Toast.makeText(this, "Today's Daily Challenge: ", Toast.LENGTH_LONG).show();

        //We use this for setting up every 24 hours. For the demo, just demonstrate that it does it 50 milliseconds after
        Long time1 = new GregorianCalendar().getTimeInMillis()+ 100;

        Intent intentAlarm1 = new Intent(this, NotifyService.class);

        // create the object
        AlarmManager alarmManager1 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        //set the alarm for particular time
        alarmManager1.set(AlarmManager.RTC_WAKEUP,time1, PendingIntent.getBroadcast(this,1,  intentAlarm1, PendingIntent.FLAG_UPDATE_CURRENT));



    }

    /**
     * Allows the User to get all of the data from Calories Activity and display the cumulative totals on the Home Activity
     */

    public void getAllData()
    {
        Cursor data = myDb.getData();
        ArrayList<Double> listData = new ArrayList<>();
        while(data.moveToNext())
        {
            listData.add(Double.parseDouble(data.getString(1)));

        }
        for (double value : listData )
        {
            total += value;
            totalCalories.setText(Double.toString(total));

        }

    }


    /**
     * creates a dialog
     */
    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * deletes the dialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }


    /**
     * Displays all of the exercise items that were added from CardioActivity and Exercise Activity and sorts them by Day.
     */
    //Replace this with volley function call
    private void populateListView()
    {
            Log.d(TAG, "populateListView: Displaying data in the ListView.");
            Cursor data = mDatabaseHelper.getData();
            ArrayList<String> listData = new ArrayList<>();
            while(data.moveToNext())
            {
                listData.add(data.getString(1));
            }
           ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
           listView.setAdapter(adapter);

    }


    /**
     * Helps with PopulateListView to display the list items in form of a listview
     */
   private void listViewItemClick() {
        ListView myList = (ListView) findViewById(R.id.listView);

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mDatabaseHelper.deleteData(id);
                populateListView();
            }
        });
    }


    /**
     * This is the multiple tabs function that allows the user to navigate between the Profile Tab, Leaderboard Tab,
     * Home tab, Groups Tab, and Friends Tab.
     */


    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(HomeActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_leaderboard:
                    Intent leaderboardIntent = new Intent(HomeActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    finish();
                    return true;
                case R.id.navigation_home:
                    //mTextMessage.setText(R.string.title_home);
                    Intent homeIntent = new Intent(HomeActivity.this, HomeActivity.class);
                    finish();
                    startActivity(homeIntent);

                    return true;
                case R.id.navigation_friends:
                    Intent friendsIntent = new Intent(HomeActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    finish();
                    return true;
            }
            return false;
        }
    };

    /**
     * creates JSON GET Request that will retrieve the exercise the user is planning on doing.
     * It will then add it to a textView to display on the home screen.
     */
//    private void makeJsonArryReq() {
//        showProgressDialog();
//        JsonArrayRequest req = new JsonArrayRequest(url,
//                new Response.Listener<JSONArray>() {
//                    @Override
//                    public void onResponse(JSONArray response) {
//
//
//                        Log.d(TAG, response.toString());
//                        try {
//                            newResponse = "";
//
//                            for (int i = 0; i < response.length(); i++) {
//
//
//                                JSONObject user = (JSONObject) response.get(i);
//
//                                if(user.getInt("uid") == userid) {
//                                    eindex = user.getInt("exerciseId");
//                                    date = user.getString("date");
//                                }
//
//
//                                listItems.add(allExercises[eindex] + "\n" + "Day: " + date);
//                                //newResponse += "Exercise #" + (i+1) + " " + allExercises[eindex] + "\n\n";
//                            }
//
//                                adapter.notifyDataSetChanged();
//
//
//
//
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                            Toast.makeText(getApplicationContext(),
//                                    "Error: " + e.getMessage(),
//                                    Toast.LENGTH_LONG).show();
//
//                        }
//
//
//                        hideProgressDialog();
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                VolleyLog.d(TAG, "Error: " + error.getMessage());
//                hideProgressDialog();
//            }
//        });
//
//        // Adding request to request queue
//        AppController.getInstance().addToRequestQueue(req);
//
//        // Cancelling request
//        // ApplicationController.getInstance().getRequestQueue().cancelAll(tag_json_arry);
//    }

    private void compareDates() {

                            newResponse = "";
                            exercises = "";

                            for (int i = 0; i < userExercise.size(); i++) {



                                int eindex = userExercise.get(i).getExerciseId();
                                String date = userExercise.get(i).getDate();
                                if(date.contains(selectedDate)) {
                                    exercises += allExercises[eindex] + "\n";
                                }

                                if(!exercises.equals(""))
                                {
                                    toast1 = Toast.makeText(getApplicationContext(), exercises, Toast.LENGTH_SHORT);
                                    toast1.show();
                                }



                            }

    }


}





