package com.example.elizabethli.mushpuppiestest;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

/**
 * Created by elizabethli on 4/12/18.
 */

public class ExerciseSurveyActivity  extends AppCompatActivity
{
    private static final String TAG = "ExerciseSurveyActivity";
    private TextView mTextMessage;
    Button answer1, answer2, answer3, answer4;

    private String point0;
    private String point1;
    private String point2;
    private String point3;
    private int score = 0;
  //  private int questionNumber = 0;

    TextView question;
    private SurveyQuestions mQuestions = new SurveyQuestions();
    //private int mQuestionsLength = mQuestions.questions.length;
    private int mQuestionsLength = 0;
    Random r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_survey);
        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);

        r = new Random();

        answer1 = (Button) findViewById(R.id.answer1);
        answer2 = (Button) findViewById(R.id.answer2);
        answer3 = (Button) findViewById(R.id.answer3);
        answer4 = (Button) findViewById(R.id.answer4);

        question = (TextView) findViewById(R.id.Question);

       // updateQuestion(r.nextInt(count));
        updateQuestion(mQuestionsLength);

        answer1.setOnClickListener(new View.OnClickListener()
        {

            @Override
             public void onClick(View view)
            {
               if(mQuestionsLength > 8)
                {

                    gameOver();
                  //  updateQuestion(r.nextInt(mQuestionsLength));
                }
                else if(answer1.getText() == point1)
                {
                    score = score + 1;
                    updateQuestion(mQuestionsLength);
                   // updateQuestion(r.nextInt(9) + 0);
                  //  updateQuestion(r.nextInt(mQuestionsLength));
                }
                else if(answer1.getText() == point2)
                {
                    score = score + 2;
                    updateQuestion(mQuestionsLength);
                   // updateQuestion(r.nextInt(9) + 0);
                  // updateQuestion(r.nextInt(mQuestionsLength));
                }
                else if(answer1.getText() == point3)
                {
                    score = score + 3;
                    updateQuestion(mQuestionsLength);
                  //  updateQuestion(r.nextInt(9) + 0);
                  //  updateQuestion(r.nextInt(mQuestionsLength));
                }

                else
                {

                    updateQuestion(mQuestionsLength);
                }
            }
        });

        answer2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
               if(mQuestionsLength > 8)
                {
                    gameOver();

                  //  updateQuestion(r.nextInt(8) + 0);
                  //  updateQuestion(r.nextInt(mQuestionsLength));
                }
                else if(answer2.getText() == point1)
                {
                    score = score + 1;
                    updateQuestion(mQuestionsLength);
                    //updateQuestion(r.nextInt(8) + 0);
                   // updateQuestion(r.nextInt(mQuestionsLength));
                }
                else if(answer2.getText() == point2)
                {
                    score = score + 2;
                    updateQuestion(mQuestionsLength);
                    //updateQuestion(r.nextInt(8) + 0);
                  // updateQuestion(r.nextInt(mQuestionsLength));
                }
                else if(answer2.getText() == point3)
                {
                    score = score + 3;
                 updateQuestion(mQuestionsLength);

                    // updateQuestion(r.nextInt(8) + 0);
                   //updateQuestion(r.nextInt(mQuestionsLength));
                }
                else
                {
                    updateQuestion(mQuestionsLength);
                }
            }
        });

        answer3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {

               if(mQuestionsLength > 8)
                {
                   // updateQuestion(r.nextInt(8) + 0);
                  // updateQuestion(r.nextInt(mQuestionsLength));

                    gameOver();
                }
                else if(answer3.getText() == point1)
                {
                    score = score + 1;
                  //  updateQuestion(r.nextInt(8) + 0);
                    updateQuestion(mQuestionsLength);
                  //  updateQuestion(r.nextInt(mQuestionsLength));
                }
                else if(answer3.getText() == point2)
                {
                    score = score + 2;
                   // updateQuestion(r.nextInt(8) + 0);
                 //   updateQuestion(r.nextInt(mQuestionsLength));
                    updateQuestion(mQuestionsLength);
                }
                else if(answer3.getText() == point3)
                {
                    score = score + 3;
                   // updateQuestion(r.nextInt(8) + 0);
                   // updateQuestion(r.nextInt(mQuestionsLength));
                    updateQuestion(mQuestionsLength);
                }

                else
                {
                    updateQuestion(mQuestionsLength);

                }
            }
        });

        answer4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
              if(mQuestionsLength > 8)
                {
                    gameOver();
                    //updateQuestion(r.nextInt(8) + 0);
                   // updateQuestion(r.nextInt(mQuestionsLength));

                }
                else if(answer4.getText() == point1)
                {
                    score = score + 1;
                    //updateQuestion(r.nextInt(9) + 0);
                 //  updateQuestion(r.nextInt(mQuestionsLength));
                    updateQuestion(mQuestionsLength);
                }
                else if(answer4.getText() == point2)
                {
                    score = score + 2;
                   // updateQuestion(r.nextInt(9) + 0);
                   // updateQuestion(r.nextInt(mQuestionsLength));
                    updateQuestion(mQuestionsLength);
                }
                else if(answer4.getText() == point3 && answer4.getText() != " ")
                {
                    score = score + 3;
                   // updateQuestion(r.nextInt(9) + 0);
                   // updateQuestion(r.nextInt(mQuestionsLength));
                    updateQuestion(mQuestionsLength);
                }

                else
                {
                    updateQuestion(mQuestionsLength);
                }
            }
        });

    }

    private void updateQuestion(int num)
    {
        question.setText(mQuestions.getQuestion(num));
        answer1.setText(mQuestions.getChoice1(num));
        answer2.setText(mQuestions.getChoice2(num));
        answer3.setText(mQuestions.getChoice3(num));
        answer4.setText(mQuestions.getChoice4(num));

        point0 = mQuestions.allocateZeroPoints(num);
        point1 = mQuestions.allocateOnePoint(num);
        point2 = mQuestions.allocateTwoPoints(num);
        point3 = mQuestions.allocateThreePoints(num);
        mQuestionsLength++;
    }

    private void gameOver() {
        String recommendedexercises = "";
        if (score >= 0 && score <= 2) {
            recommendedexercises = "Walking and lower intensity Cycling, Yoga, Pilates, Tai Chi";
        } else if (score >= 3 && score <= 4) {
            recommendedexercises = "Walking and lower intensity Cycling, Yoga, Pilates, Tai Chi, Squats, Lunges, Deadlifts";
        } else if (score >= 5 && score <= 8) {
            recommendedexercises = "Tennis, Cycling, Jogging, Squats, Lunges, Deadlifts, and faster-paced Walking";
        } else if (score >= 9 && score <= 12) {
            recommendedexercises = "Tennis, Jogging, Elliptical Machine, Step Aerobics, Brisk Walking, Medium-Intensity Pilates";
        } else if (score >= 13 && score <= 15) {
            recommendedexercises = "Swimming, Brisk Walking, Cycling under 10mph, Volleyball, Softball/Baseball, Faster Jogging, Bench press, Chin Ups, Dumbbells, Barbells";
        } else if (score >= 16 && score <= 18) {
            recommendedexercises = "Hiking, Stairs, Sprinting, Jumping Rope, Bench Presses, High pulls, Dips, Shoulder Press";
        } else if (score >= 19 && score <= 21)
        {
            recommendedexercises = "Toe Touch, Walking Lunges, Butt kicks, High Knees, Hiking, Any High Intensity Lifting Exercises";
        }
        else
        {
            recommendedexercises = "Swimming, Dancing, High intensity Aerobics, any high intensity Cardio Exercises, any high intensity Lifting Exercises";
        }
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ExerciseSurveyActivity.this);
         alertDialogBuilder
                 .setMessage("Your recommended exercises: " + recommendedexercises)
                 .setCancelable(false)
                 .setPositiveButton("Retake Survey",
                         new DialogInterface.OnClickListener() {
                             @Override
                             public void onClick(DialogInterface dialog, int which) {
                                 startActivity(new Intent(getApplicationContext(), ExerciseSurveyActivity.class));
                             }
                         })
                 .setNegativeButton("Exit",
                         new DialogInterface.OnClickListener() {
                             @Override
                             public void onClick(DialogInterface dialog, int which) {
                                finish();
                             }
                         });

         AlertDialog alertDialog = alertDialogBuilder.create();
         alertDialog.show();
    }

}
