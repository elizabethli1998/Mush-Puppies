package com.example.elizabethli.mushpuppiestest;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.example.elizabethli.mushpuppiestest.stepInterface.StepListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.*;


import java.util.ArrayList;
import java.util.Calendar;
import com.example.elizabethli.mushpuppiestest.CalorieDatabase.CalorieDatabaseHelper;
import com.example.elizabethli.mushpuppiestest.CalorieDatabase.DailyCalorieDatabaseHelper;

/**
 * @author nathanoran
 * @author justinlee
 */
public class ProfileActivity extends AppCompatActivity implements SensorEventListener, StepListener, View.OnClickListener {
    StepsDatabaseHelper Db1;
    CalorieDatabaseHelper myDb;

    //this is the default textview from the template for the bottom navigation activity
    //I left it in so you can still see how the default navigation activity works
    private Button btnUpdateSettings;
    private Button btnLogOut;

    private TextView userName;
    private TextView firstName;
    private TextView lastName;
    private TextView feet;
    private TextView inches;
    private TextView age;
    private TextView weight;
    private TextView totalSteps;
    private TextView newUserName;
    private TextView totalCalories;
    private TextView totalCaloriesView;

    private TextView cumulativeSteps;
    private TextView DailyStep;
    private StepDetector simpleStepDetector;
    private int numSteps;
    private int total;
    private Button notificationsButton;
    private TextView mTextMessage;
    private String TAG = ProfileActivity.class.getSimpleName();
    private Button btnUpdate;
    private Button graphButton;
    private TextView msgResponse;
    private ProgressDialog pDialog;
    private String jsonResponse;
    private String url = "http://proj-309-yt-7.cs.iastate.edu:8080/allusers";
    private int userId = Global.getId();


    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";



    /**
     * This method constructs the entire Update Activity
     * it initializes the proper layout xml
     *
     * Then defines the EditText and Button objects
     *
     * Also defines CLick Listeners for all buttons
     *
     * Also works with the steps SQLite Database
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        Db1 = new StepsDatabaseHelper(this);
        myDb = new CalorieDatabaseHelper(this);




        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);


        //initialization for the bottom navigation stuff
        //mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);

        btnUpdateSettings = (Button) findViewById(R.id.btnUpdate);
        btnUpdateSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent updateIntent = new Intent(ProfileActivity.this, UpdateActivity.class);
                startActivity(updateIntent);
                finish();
            }
        });

        notificationsButton = (Button) findViewById(R.id.notificationsButton);
        notificationsButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ProfileActivity.this, NotificationSettingsActivity.class);
                startActivity(intent);
                finish();
            }

        });

        graphButton = (Button) findViewById(R.id.healthButton);
        graphButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent graphIntent = new Intent(ProfileActivity.this, GraphActivity.class);
                graphIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                graphIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                graphIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(graphIntent);
                finish();

            }

        });

        btnLogOut = (Button) findViewById(R.id.btnLogOut);

        btnLogOut.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent logOutIntent = new Intent(ProfileActivity.this, LoginActivity.class);
                startActivity(logOutIntent);
                Global.clearGlobal();
                finish();

            }

        });

        //DailyStep = (TextView) findViewById(R.id.txtDailySteps);
        userName = (TextView) findViewById(R.id.userName);
        firstName = (TextView) findViewById(R.id.firstName);
        lastName = (TextView) findViewById(R.id.lastName);
        feet = (TextView) findViewById(R.id.txtFeet);
        inches = (TextView) findViewById(R.id.txtInch);
        age = (TextView) findViewById(R.id.txtYears);
        weight = (TextView) findViewById(R.id.txtPounds);
        totalSteps = (TextView) findViewById(R.id.totalStepsView);
        totalCalories = (TextView) findViewById(R.id.totalCaloriesView);


        userName.setText(Global.getusername());
        firstName.setText(Global.getfirstname());
        lastName.setText(Global.getlastname());
        feet.setText(Integer.toString(Global.getheight()/12));
        inches.setText(Integer.toString(Global.getheight()%12));
        age.setText(Integer.toString(Global.getage()));
        weight.setText(Integer.toString(Global.getWeight()));
        totalCalories.setText(Integer.toString(Global.gettotalcalories()));
        totalSteps.setText(Integer.toString(Global.gettotalsteps()));
        //DailyStep.setText(Integer.toString(Global.getDailySteps()));



        getAllData();

        //for each textview:

        //userName.setText(<value recieved from json>, TextView.BufferType.EDITABLE);
        //firstName.setText(<value recieved from json>, TextView.BufferType.EDITABLE);
        //lastName.setText(<value recieved from json>, TextView.BufferType.EDITABLE);
        //feet.setText(<value recieved from json>, TextView.BufferType.EDITABLE);
        //inches.setText(<value recieved from json>, TextView.BufferType.EDITABLE);
        //age.setText(<value recieved from json>, TextView.BufferType.EDITABLE);
        //weight.setText(<value recieved from json>, TextView.BufferType.EDITABLE);
        //totalSteps.setText(<value recieved from json>, TextView.BufferType.EDITABLE);


        // Get an instance of the SensorManager
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        assert sensorManager != null;
        Sensor accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        simpleStepDetector = new StepDetector();
        simpleStepDetector.registerListener(this);
        numSteps = 0;
        sensorManager.registerListener(ProfileActivity.this, accel, SensorManager.SENSOR_DELAY_FASTEST);

        //makeJsonArryReq();

        Db1.insertNewDay(Calendar.DAY_OF_YEAR);
     //  DailyStep.setText("0");



    }

    /**
     * This is the bottom navigation view
     *
     * Starts the corresponding Android Activity based on the menu item selected.
     */
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    //mTextMessage.setText(R.string.title_leaderboard);
                    return true;
                case R.id.navigation_leaderboard:
                    Intent profileIntent = new Intent(ProfileActivity.this, LeaderboardActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(ProfileActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                    return true;
                case R.id.navigation_friends:
                    Intent friendsIntent = new Intent(ProfileActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    finish();
                    return true;
            }
            return false;
        }
    };

    public void getAllData()
    {
        Cursor data = myDb.getData();
        ArrayList<Double> listData = new ArrayList<>();
        while(data.moveToNext())
        {
            listData.add(Double.parseDouble(data.getString(1)));

        }
        for (double value : listData )
        {
            total += value;
            totalCalories.setText(Double.toString(total));

        }

    }

    /**
     *
     * @param sensor
     * @param accuracy
     */
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            simpleStepDetector.updateAccel(
                    event.timestamp, event.values[0], event.values[1], event.values[2]);
        }
    }

    @Override
    public void step(long timeNs) {
        numSteps++;
        //Db1.saveCurrentSteps(numSteps);
        Global.setDailySteps(Global.getDailySteps() + 1);
        Global.settotalsteps(Global.gettotalsteps()+ 1);
      // DailyStep.setText(String.valueOf(numSteps));
   //    cumulativeSteps.setText(String.valueOf(Db1.getTotalWithoutToday() + Db1.getCurrentSteps()));
       //Db1.addToLastEntry(Db1.getCurrentSteps()+numSteps);
    }

    /**
     *
     * @param view
     */
    @Override
    public void onClick(View view) {

    }

    /**
     * Turns on the pDialog
     */
    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * Turns off the pDialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    /**
     *
     */
    private void makeJsonArryReq() {
        showProgressDialog();
        JsonArrayRequest req = new JsonArrayRequest(/*Const.URL_JSON_ARRAY*/ url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {


                        Log.d(TAG, response.toString());
                        try {



                            jsonResponse = "";

                            for(int i = 0; i < response.length(); i++) {
                                JSONObject user = (JSONObject) response.get(i);
                                if(user.getInt("id") == userId) {
                                    int id = user.getInt("id");
                                    String username = user.getString("username");
                                    int steps = user.getInt("steps");
                                    String firstname = user.getString("firstName");
                                    String lastname = user.getString("lastName");
                                    int height = user.getInt("height");
                                    int weights = user.getInt("weight");



                                    userName.setText(userName.getText() + ": " + username);
                                    firstName.setText(firstName.getText() + ": " + firstname);
                                    lastName.setText(lastName.getText() + ": " + lastname);
                                    weight.setText(weight.getText() + ": " + weights);


                                }
                            }
                            //feet.setText(<value recieved from json>);
                            //inches.setText(<value recieved from json>);
                            //age.setText(<value recieved from json>);
                            //weight.setText(<value recieved from json>);
                            //totalSteps.setText(steps);




                            msgResponse.setText(jsonResponse);


                        }
                        catch(JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),
                                    "Error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();

                        }




                        hideProgressDialog();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                hideProgressDialog();
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(req);

        // Cancelling request
        // ApplicationController.getInstance().getRequestQueue().cancelAll(tag_json_arry);
    }

    /**
     *
     */

}


