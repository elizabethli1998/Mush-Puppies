package com.example.elizabethli.mushpuppiestest;

/**
 * @author Justin Lee
 *
 * This Activity takes in Daily Steps data from all Users and sorts them in form of a Leaderboard, placing the one
 * with the most amount of steps per day up first along with their username and other information and so on
 */

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Creates the leaderboard and takes in the step information and user information
 * and displays it in order, with the user with the most daily steps as first and so on
 */
public class LeaderboardActivity extends AppCompatActivity implements View.OnClickListener {

    //this is the default textview from the template for the bottom navigation activity
    //I left it in so you can still see how the default navigation activity works
    private TextView mTextMessage;
    private TextView leaderBoardPerson;
    private ProgressDialog pDialog;
    private String url = "http://proj-309-yt-7.cs.iastate.edu:8080/allusers";
    private String TAG = LeaderboardActivity.class.getSimpleName();
    String newResponse;
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);

        //initialization for the bottom navigation stuff
        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);

        leaderBoardPerson = (TextView) findViewById(R.id.leaderboardPerson);
        newResponse = "";
        leaderBoardPerson.setMovementMethod(new ScrollingMovementMethod());
        makeJsonArryReq();
    }

    /**
     * This is the multiple tabs function that allows the user to navigate between the Profile Tab, Leaderboard Tab,
     * Home tab, Groups Tab, and Friends Tab.
     */

    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(LeaderboardActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_leaderboard:
                   // mTextMessage.setText(R.string.title_leaderboard);
                    Intent leaderboardIntent = new Intent(LeaderboardActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    finish();

                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(LeaderboardActivity.this, HomeActivity.class);
                    finish();
                    startActivity(homeIntent);
                    return true;
                case R.id.navigation_friends:
                    Intent friendsIntent = new Intent(LeaderboardActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    finish();
                    return true;
            }
            return false;
        }
    };

    /**
     * create dialog
     */
    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * delete dialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    /**
     * Creates a JSON GET Request to retrieve username, steps, first name, and last name
     */
    private void makeJsonArryReq() {
        showProgressDialog();
        JsonArrayRequest req = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {


                        Log.d(TAG, response.toString());
                        try {
                            //response = sortBySteps(response);

                            for (int i = 0; i < response.length(); i++) {


                                JSONObject user = (JSONObject) response.get(i);


                                String username = user.getString("username");
                                int steps = user.getInt("totalsteps");
                                String firstname = user.getString("firstname");
                                String lastname = user.getString("lastname");


                                newResponse += "Username: " + username + "\n";
                                newResponse += "Name: " + firstname + " ";
                                newResponse += lastname + " \n";
                                newResponse += "Number of Steps: " + steps + "\n\n";
                            }


                            leaderBoardPerson.setText(newResponse);


                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),
                                    "Error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();

                        }


                        hideProgressDialog();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                hideProgressDialog();
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(req);

        // Cancelling request
        // ApplicationController.getInstance().getRequestQueue().cancelAll(tag_json_arry);
    }

    @Override
    public void onClick(View view) {

    }

    /**
     * Sorts the JSON Array by the amount of steps of each user, from highest to lowest
     * @param response
     * JSON Array with users
     * @return
     * JSON Array sorted by steps
     * @throws JSONException
     */
    private JSONArray sortBySteps(JSONArray response) throws JSONException {


        JSONArray jsonArr = response;
        JSONArray sortedJsonArray = new JSONArray();

        List<JSONObject> jsonValues = new ArrayList<JSONObject>();
        for (int i = 0; i < jsonArr.length(); i++) {
            jsonValues.add(jsonArr.getJSONObject(i));
        }
        Collections.sort(jsonValues, new Comparator<JSONObject>() {



            @Override
            public int compare(JSONObject a, JSONObject b) {
                String steps1 = "";
                String steps2 = "";

                try {
                    steps1 = Integer.toString(a.getInt("totalsteps"));
                    steps2 = Integer.toString(b.getInt("totalsteps"));

                } catch (JSONException e) {
                }

                return steps1.compareTo(steps2);

            }
        });

        for (int i = jsonArr.length()-1 ; i >= 0; i--) {
            sortedJsonArray.put(jsonValues.get(i));
        }
        return sortedJsonArray;
    }




}
