package com.example.elizabethli.mushpuppiestest;
/**
 * @author Elizabeth Li
 *
 *This activity works with adding exercises onto the exercise list.
 * Its sole purpose is to provide navigation for the Cardio Activity and Lifting Activity classes,
 * allowing the User to choose which category of exercises to add onto the exercise list
 *
 */

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * This class works with navigation between Home Activity, Cardio Activity, and Lifting activity, and provides
 * information on what each category of exercises entails, helping the user decide which exercises to add
 * to the exercise list.
 */

public class AddExerciseActivity extends AppCompatActivity
{
    private static final String TAG = "AddExerciseActivity";
    private TextView mTextMessage;
    Button backButton;
    Button cardioButton;
    Button liftingButton;
    Button generateButton;

    private ProgressDialog pDialog;
    String task = "";
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";




    /**
     * 
     * @param savedInstanceState
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        setContentView(R.layout.activity_add_exercise);

        //initialization for the bottom navigation stuff
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);

        backButton = (Button) findViewById(R.id.backButton);
        cardioButton = (Button) findViewById(R.id.cardioButton);
        liftingButton = (Button) findViewById(R.id.liftingButton);
        generateButton = (Button) findViewById(R.id.generateButton);

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);



        generateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(AddExerciseActivity.this, ExerciseSurveyActivity.class);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(addExerciseIntent);
            }

        });
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(AddExerciseActivity.this, HomeActivity.class);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(addExerciseIntent);
                finish();
            }

        });

        cardioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(AddExerciseActivity.this, CardioActivity.class);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(addExerciseIntent);
            }

        });

        liftingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(AddExerciseActivity.this, LiftingActivity.class);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                addExerciseIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(addExerciseIntent);
            }

        });
    }

    /**
     * creates dialog
     */
    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * dismisses dialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    /**
     * This is the multiple tabs function that allows the user to navigate between the Profile Tab, Leaderboard Tab,
     * Home tab, Groups Tab, and Friends Tab.
     */
    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(AddExerciseActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_leaderboard:
                    //mTextMessage.setText(R.string.title_leaderboard);
                    Intent leaderboardIntent = new Intent(AddExerciseActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(AddExerciseActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                    return true;
                case R.id.navigation_friends:
                    Intent friendIntent= new Intent(AddExerciseActivity.this, FriendsActivity.class);
                    startActivity(friendIntent);
                    //mTextMessage.setText(R.string.title_friends);
                    return true;
            }
            return false;
        }
    };
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_mush_puppies, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
