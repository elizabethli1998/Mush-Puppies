package com.example.elizabethli.mushpuppiestest;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by meghnavaidya on 4/14/18.
 */

public class GraphActivity extends AppCompatActivity {

    LineGraphSeries<DataPoint> series;
    Button bButton;
    String postUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/myweek";
    private ProgressDialog pDialog;
    private static final String TAG = "GraphActivity";
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";
    ArrayList<Integer> dailyStep = new ArrayList<Integer>();
    ArrayList<Integer> dailyCalories = new ArrayList<Integer>();
    ArrayList<String> dates = new ArrayList<String>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        pDialog = new ProgressDialog(this);

        getDaily();


        GraphView graph = findViewById(R.id.graph1);
        LineGraphSeries<DataPoint> steps = new LineGraphSeries<>(new DataPoint[] {
                new DataPoint(1, 0),
                new DataPoint(2, 0),
                new DataPoint(3, 0),
                new DataPoint(4, 0),
                new DataPoint(5, 0),
                new DataPoint(6, 1359),
                new DataPoint(7, 0),

        });
        graph.addSeries(steps);
        graph.getGridLabelRenderer().setGridColor(Color.BLUE);
        steps.setColor(Color.RED);


        LineGraphSeries<DataPoint> calories = new LineGraphSeries<>(new DataPoint[] {
                new DataPoint(1, 0),
                new DataPoint(2, 0),
                new DataPoint(3, 0),
                new DataPoint(4, 0),
                new DataPoint(5, 0),
                new DataPoint(6, 4281),
                new DataPoint(7, 0),

        });
        graph.addSeries(calories);
        calories.setColor(Color.MAGENTA);


        graph.setTitle("Health Data From the Last 7 Days");
        graph.setTitleColor(Color.BLUE);
        graph.setTitleTextSize(60);

        bButton = (Button) findViewById(R.id.bButton);
        bButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent back = new Intent(GraphActivity.this, ProfileActivity.class);
                startActivity(back);
                finish();
            }

        });


    }



    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * delete dialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    private void getDaily() {
        showProgressDialog();
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("uid", Global.getId());


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, postUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                        try {
                            JSONArray temp =  response.getJSONArray("dailylogs");
                            for(int i = 0; i < temp.length(); i++) {
                                JSONObject user = (JSONObject) temp.get(i);
                                int step = user.getInt("dailySteps");
                                String date = user.getString("date");
                                int calorie = user.getInt("dailyCalories");
                                dailyStep.add(step);
                                dates.add(date);
                                dailyCalories.add(calorie);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {

        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }




}
