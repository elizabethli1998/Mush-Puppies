package com.example.elizabethli.mushpuppiestest;

/**
 * @author Elizabeth Li, Justin Lee
 * This Activity works with the Goals feature for MushPuppies. User can add goals, delete goals, indicate that they are done,
 * and customize goals and have them appear in form of a list, allowing User to track progress and other milestones.
 */

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.elizabethli.mushpuppiestest.GoalDatabase.GoalDataBase;
import com.example.elizabethli.mushpuppiestest.GoalDatabase.GoalDatabaseHelper;
import com.example.elizabethli.mushpuppiestest.VolleyServices.Goals;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * This Class is where the User adds, deletes, customizes, and indicates when Goals are done. All changes appear
 * on the goals list.
 */
public class GoalActivity extends AppCompatActivity
{
    private static final String TAG = "GoalActivity";
    private GoalDatabaseHelper mHelper;
    private TextView goalListView;
    private ArrayAdapter<String> mAdapter;
    Button backButton;
    Button doneButton;
    Button updateButton;
    Button deleteButton;
    private ProgressDialog pDialog;
    String task = "";
    String deletemessage = "";
    String newResponse = "";
    ArrayAdapter<String> adapter;
    ArrayList<String> listItems=new ArrayList<String>();
    int i = 1;
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";

    private String url = "http://proj-309-yt-7.cs.iastate.edu:8080/allGoals";
    private String postUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/addGoal";
    private String deleteUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/goaldelete";
    private String goalUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/getgoals/";
    int userid = Global.getId();
    ArrayList<Goals> goal;
    ArrayList<Goals> allGoals = new ArrayList<Goals>();



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);

        goalListView = (TextView) findViewById(R.id.listOfGoals);

        getAllGoals();
        Global.setGoals(allGoals);
        goal = Global.getGoals();

        //updateUI();
        getAllGoals();

        backButton = (Button) findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(GoalActivity.this, HomeActivity.class);
                startActivity(addExerciseIntent);
                finish();
            }

        });

      deleteButton = (Button) findViewById(R.id.deleteButton);
        final EditText deleteText = new EditText(this);
        final AlertDialog.Builder dialog1 = new AlertDialog.Builder(this);
        deleteButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                dialog1.setTitle("Delete Goal");
                dialog1.setMessage("Enter the Goal you wish to delete: ");
                dialog1.setView(deleteText)
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogue, int which) {
                                task = String.valueOf(deleteText.getText());

                                try {
                                    postDeleteJsonObj();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                //updateUI();
                                //Toast.makeText(this, deletemessage, Toast.LENGTH_LONG).show();

                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create();
                dialog1.show();
                                            }
                                        });



        doneButton = (Button) findViewById(R.id.doneButton);
        updateButton = (Button) findViewById(R.id.deleteButton);
    }

    /**
     * create dialog
     */
    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * delete dialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_mush_puppies, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add_goal:
                final EditText taskEditText = new EditText(this);
                AlertDialog dialog = new AlertDialog.Builder(this)
                        .setTitle("New Goal")
                        .setMessage("Add a new goal")
                        .setView(taskEditText)
                        .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogue, int which) {
                                task = String.valueOf(taskEditText.getText());
                                try {
                                    postJsonObj();
                                    //updateUI();
                                    getAllGoals();


                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create();
                dialog.show();

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void getAllGoals() {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("uid", Global.getId());


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, goalUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                        try {
                            JSONArray temp =  response.getJSONArray("goals");
                            newResponse = "";
                            for(int i = 0; i < temp.length(); i++) {
                                JSONObject user = (JSONObject) temp.get(i);
                                String tempGoal = user.getString("goal");
                                int complete = user.getInt("complete");
                                int goalId = user.getInt("goalsId");
                                newResponse += "Exercise: " + tempGoal + "\n\n";
                                Goals goalg = new Goals(goalId, Global.getId(), tempGoal, complete);
                                allGoals.add(goalg);
                            }
                            goalListView.setText(newResponse);



                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);

    }

    private void updateUI() {
        showProgressDialog();
        newResponse = "";
        for (int i = 0; i < allGoals.size(); i++) {

            String newExercise = allGoals.get(i).getGoal();

            newResponse += "Goal #" + (i + 1) + " " + newExercise + goal.size() + "\n\n";

        }
        goalListView.setText(newResponse);
        hideProgressDialog();


    }

    /**
     * Deletes goal item from the list and removes the item from the database
     * @param view the item on the list that is to be deleted
     */
    public void deleteTask(View view) {
        View parent = (View) view.getParent();
        TextView goalTextView = (TextView) parent.findViewById(R.id.goal_title);
        String task = String.valueOf(goalTextView.getText());
        int goalsId = 1;


        showProgressDialog();



        Map<String, String> params = new HashMap<String, String>();
        params.put("uid", Integer.toString(Global.getId()));
        params.put("goal", task);
        params.put("goalsId", Integer.toString(goalsId));









        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, deleteUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());

                        getAllGoals();
                        //updateUI();
                        pDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();

            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);

    }

    /**
     * Indicates that the item on the goals list is done, adding a ": Done" to the end of the item
     * @param view the item on the list that is going to be indicated as finished
     */

  public void finishTask(View view) throws JSONException {
      View parent = (View) view.getParent();
      TextView goalTitle = (TextView) parent.findViewById(R.id.goal_title);
      String  task = String.valueOf(goalTitle.getText());
      SQLiteDatabase db = mHelper.getWritableDatabase();
      ContentValues values = new ContentValues();
      if(!task.contains("Done")) {
          values.put(GoalDataBase.GoalEntry.COL_TASK_TITLE, task + ":" + " " + "Done");
          db.delete(GoalDataBase.GoalEntry.TABLE, GoalDataBase.GoalEntry.COL_TASK_TITLE + " = ?", new String[]{task});
          db.replace(GoalDataBase.GoalEntry.TABLE, GoalDataBase.GoalEntry.COL_TASK_TITLE, values);
          db.close();
          postDeleteJsonObj();
          getAllGoals();
          //updateUI();
      }
      else
      {
          db.close();
      }

  }



    /**
     * creates a JSON POST Request that will send out the user id, goal, and if the goal is complete or not
     * @throws JSONException
     */
    private void postJsonObj() throws JSONException {
        showProgressDialog();

            Map<String, Object> params = new HashMap<String, Object>();
            params.put("uid", Global.getId());
            params.put("goal", task);
            i++;

            Goals tempGoal = new Goals(3, userid, task, 0);
            goal.add(tempGoal);



     //REPLICATE this area for the Calories?

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, postUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                        //updateUI();
                        getAllGoals();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }

    private void postDeleteJsonObj() throws JSONException {
        showProgressDialog();

        Map<String, Object> params = new HashMap<String, Object>();
        params.put("uid", Global.getId());
        params.put("goal", task);
        params.put("complete", "1");

        for(int i = 0; i < goal.size(); i++) {
            if(goal.get(i).getGoal().equals(task)) {
                goal.remove(i);
            }
        }



        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, deleteUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                        //updateUI();
                        getAllGoals();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }




}
