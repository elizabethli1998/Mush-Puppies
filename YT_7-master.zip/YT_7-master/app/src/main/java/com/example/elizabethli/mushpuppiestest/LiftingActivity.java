package com.example.elizabethli.mushpuppiestest;

/**
 * @author Elizabeth Li
 * This is the Lifting Activity Class that has all of the lifting exercises in form of a checklist
 * and all items that are checked will be added onto the Exercise List on the Home Activity. This Activity
 * can be accessed from the AddExerciseActivity.
 */

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Button;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.elizabethli.mushpuppiestest.ExerciseDatabase.ExerciseDatabaseHelper;
import org.json.JSONObject;

/**
 * This displays all of the Lifting Exercises in form of a large checklist and each checklist item is a lifting exercise
 * Anything that is checked will be added to a database for exercises and then added to the Exercise List on the Home Activity
 */

public class LiftingActivity extends AppCompatActivity
{
    Button backButton;
    private TextView mTextMessage;
    private static final String TAG = "CardioActivity";
    ExerciseDatabaseHelper mDatabaseHelper;
    private ProgressDialog pDialog;
    ArrayList<String> selectedItems = new ArrayList<>();
    int i = 1;
    int index;

    private String postUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/addexercise";
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";
    private  String [] allExercises = Global.getallExercises();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lifting);
        mDatabaseHelper = new ExerciseDatabaseHelper(this);

        //initialization for the bottom navigation stuff
        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);

        backButton = (Button) findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(LiftingActivity.this, AddExerciseActivity.class);
                startActivity(addExerciseIntent);
                finish();
            }

        });

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);


        ListView checked = (ListView) findViewById(R.id.low_intensity_list);
        checked.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        String[] items= {"Full Squat (5 Sets, 10 reps)", "Hack Squat (3 Sets, 20 Reps)","Barbell Lunge (3 Sets, 10 Reps/Leg)", "Single Leg Deadlift (2 Sets, " +
                "10 Reps/Leg)", "Romanian Deadlift (3 Sets, 10 Reps)", "Leg Extension (3 Sets, 10 Reps)", "Leg Press (4 Sets, 10 Reps)",  "Seated Legs Curl (4 Sets, 10 Reps)",
                "Lying Leg Curl (3 Sets, 12-15 Reps)", "Bench Press (8 Sets, 8 Reps)", "Chin-Up (3 Sets, 6 Reps)", "Barbell High Pull (3 Sets, 8 Reps)", "Dips (3 Sets, 10-12 Reps)",
                "Dumbbell One-Arm Shoulder Press (3 Sets, 10 Reps)", "Standing Dumbbell Upright Row (3 Sets, 10 Reps)", "Incline Pushup (3 Sets, 8-15 Reps)",
                "Lying Dumbbell Tricep Extension (3 Sets, 8 Reps)", "Plank and Rotate (3 Sets, 10 Reps)", "Coordination Fly (2 Sets, 15 Reps)", "Standing Side Bend (2 Sets, 12 Reps)",
                "Dumbbell Side Bend (2 Sets, 15 Reps)", "Twisting Wood Chop with Medicine Ball (3 Sets, 15 Reps)", "Shoulder Press and Side Crunch (2 Sets, 15 Reps)",
                "Alphabet Abs (2 Sets, 15 Reps)", "Standing Twists (3 Sets, 30 Reps)"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.item_cardio_list, R.id.text_workout,items);
        checked.setAdapter(adapter);
        checked.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedItem = ((TextView)view).getText().toString();

                if(selectedItems.contains(selectedItem))
                {
                    selectedItems.remove(selectedItem); //This unchecks the item
                }
                else
                {
                    selectedItems.add(selectedItem);
                    index = findIndex(allExercises, selectedItem);
                    postJsonObj(index);

                }
            }
        });
        ListView checked2 = (ListView) findViewById(R.id.medium_intensity_list);
        checked2.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        String[] items2 = {"Bench Press (8 Sets, 8 Reps)", "Chin-Up (3 Sets, 6 Reps)", "Barbell High Pull (3 Sets, 8 Reps)", "Dips (3 Sets, 10-12 Reps)",
        "Dumbbell One-Arm Shoulder Press (3 Sets, 10 Reps)", "Standing Dumbbell Upright Row (3 Sets, 10 Reps)", "Incline Pushup (3 Sets, 8-15 Reps)", "Lying Dumbbell Tricep Extension (3 Sets, 8 Reps)"};
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, R.layout.item_cardio_list, R.id.text_workout,items2);
        checked2.setAdapter(adapter2);
        checked2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedItem = ((TextView)view).getText().toString();

                if(selectedItems.contains(selectedItem))
                {
                    selectedItems.remove(selectedItem); //This unchecks the item
                }
                else
                {
                    selectedItems.add(selectedItem);
                    index = findIndex(allExercises, selectedItem);
                    postJsonObj(index);
                    //AddData(selectedItem);

                }
            }
        });

        ListView checked3 = (ListView) findViewById(R.id.high_intensity_list);
        checked3.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        String[] items3 = {"Plank and Rotate (3 Sets, 10 Reps)", "Coordination Fly (2 Sets, 15 Reps)", "Standing Side Bend (2 Sets, 12 Reps)",
        "Dumbbell Side Bend (2 Sets, 15 Reps)", "Twisting Wood Chop with Medicine Ball (3 Sets, 15 Reps)", "Shoulder Press and Side Crunch (2 Sets, 15 Reps)",
        "Alphabet Abs (2 Sets, 15 Reps)", "Standing Twists (3 Sets, 30 Reps)"};
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, R.layout.item_cardio_list, R.id.text_workout,items3);
        checked3.setAdapter(adapter3);
        checked3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedItem = ((TextView)view).getText().toString();

                if(selectedItems.contains(selectedItem))
                {
                    selectedItems.remove(selectedItem); //This unchecks the item
                }
                else
                {
                    selectedItems.add(selectedItem);
                   // AddData(selectedItem);
                    index = findIndex(allExercises, selectedItem);
                    postJsonObj(index);

                }
            }
        });


    }

    /**
     * shows Dialog
     */
    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * hides dialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    /**
     * Adds lifting exercises onto the exercise database and the exercise list on the home page
     * @param newEntry The item that is being added to the exercise list
     * This method also provides a message that shows that the exercise list was indicated
     */

    public void AddData(String newEntry)
    {
        boolean insertData = mDatabaseHelper.addData(newEntry);

        if(insertData)
        {
            Toast.makeText(getApplicationContext(),"Updated Exercise List!",Toast.LENGTH_SHORT).show();

        }
    }

    /**
     * This is the multiple tabs function that allows the user to navigate between the Profile Tab, Leaderboard Tab,
     * Home tab, Groups Tab, and Friends Tab.
     */
    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(LiftingActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_leaderboard:
                   // mTextMessage.setText(R.string.title_leaderboard);
                    Intent leaderboardIntent = new Intent(LiftingActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    finish();
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(LiftingActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                    return true;

                case R.id.navigation_friends:
                    Intent friendIntent = new Intent(LiftingActivity.this, FriendsActivity.class);
                    startActivity(friendIntent);
                    finish();
                    //mTextMessage.setText(R.string.title_friends);
                    return true;
            }
            return false;
        }
    };
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_mush_puppies, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Creates a JSON POST Request that will send the exercise, user id, and the date.
     * It will then add it to the queue.
     * @param selectedItem
     * Exercise wanting to be added
     */
    private void postJsonObj(int selectedItem) {
        showProgressDialog();
        //String tempUrl = postUrl;

        //String date = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault()).format( new Date());
        Date c = Calendar.getInstance().getTime();

        SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy");
        String date = df.format(c);


        Map<String, String> params = new HashMap<String, String>();
        params.put("uid", Integer.toString(Global.getId()));
        params.put("androidId", Integer.toString(selectedItem));
        params.put("date", date);


       // tempUrl += "?uid=69&exerciseId=" + select +"date=" + date;
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, postUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }

    /**
     * finds the index of item in items array
     * @param items
     * array of all exercises
     * @param item
     * exercise wanting to be put into the JSON Request
     * @return
     * index of item
     */
    public int findIndex(String [] items, String item) {
        for(int i = 0; i < items.length; i++) {
            if(items[i].equals(item)) {
                return i;
            }
        }
        return 1;
    }
}
