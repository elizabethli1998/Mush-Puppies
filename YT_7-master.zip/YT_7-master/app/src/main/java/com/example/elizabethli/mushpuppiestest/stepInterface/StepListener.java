package com.example.elizabethli.mushpuppiestest.stepInterface;

/**
 * Created by meghnavaidya on 2/21/18.
 */

/**
 * Listens for alerts about steps being detected.
 */

public interface StepListener {

    /**
     * Called when a step has been detected.  Given the time in nanoseconds at
     * which the step was detected.
     * @param timeNs - the nanoseconds between detecting steps
     */

    public void step(long timeNs);

}