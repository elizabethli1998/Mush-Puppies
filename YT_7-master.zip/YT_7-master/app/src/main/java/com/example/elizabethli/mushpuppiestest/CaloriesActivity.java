package com.example.elizabethli.mushpuppiestest;

/**
 * @author Elizabeth Li
 * This activity works with calculating calories burned per exercise and weight and stores it
 * into a cumulative list and a daily list for the user to see. The cumulative calories burned
 * data also appears on the HomeActivity and daily calories burned appears inside Calendar.
 */

import android.app.Notification;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.elizabethli.mushpuppiestest.CalorieDatabase.CalorieDatabaseHelper;
import com.example.elizabethli.mushpuppiestest.CalorieDatabase.DailyCalorieDatabaseHelper;
import com.example.elizabethli.mushpuppiestest.VolleyServices.Goals;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * This class works with calculating calories burned per exercise, exercise length, and weight and stores
 * the data into a daily log and cumulative log of total calories burned, also sending the data into the home
 * activity. All exercises provided on the list are the same exercises listed in Cardio and Lifting Activities
 */

public class CaloriesActivity extends AppCompatActivity {
    private static final int NOTI_PRIMARY1 = 1100;
    private static final int NOTI_PRIMARY2 = 1101;
    private NotificationHelper noti;
    CalorieDatabaseHelper myDb;
    DailyCalorieDatabaseHelper myDb1;
    TextView totalTextView;
    TextView cumulativeView;
    EditText weightTxt;
    EditText durationTxt;
    double milesPerHour;
    double caloriesBurned;
    double total = 0;
    String dailyTotal = "";
    String exerciseType;
    Button btnAddData;
    Button calcBtn;
    Button backButton;
    Button view;
    Button view1;
    Button clear;
    String date = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault()).format(new Date());
    private TextView mTextMessage;
    int burnedCalories;
    private ProgressDialog pDialog;
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";
    private static final String TAG = "CaloriesActivity";
    private String postUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/logcalories";
    private String caloriesUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/myweek";
    private String buffer1;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calories);

        //initialization for the bottom navigation stuff
        mTextMessage = (TextView) findViewById(R.id.caloriesTextView);
        mTextMessage.setText(R.string.title_calories);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);

        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);

        myDb = new CalorieDatabaseHelper(this);
        myDb1 = new DailyCalorieDatabaseHelper(this);

        btnAddData = (Button)findViewById(R.id.button_add);
        calcBtn = (Button) findViewById(R.id.calcBtn);
        view = (Button) findViewById(R.id.button_view);
        view1 = (Button) findViewById(R.id.button_view1);
        clear = (Button) findViewById(R.id.clear);
        totalTextView = (TextView) findViewById(R.id.totalTextView);
        cumulativeView = (TextView) findViewById(R.id.cumulativeView);
        cumulativeView.setText(Integer.toString(Global.gettotalcalories()));
        weightTxt = (EditText) findViewById(R.id.weightTxt); //btw I changed these ids to id's in the xml files, but they probs don't need to be here
        durationTxt = (EditText) findViewById(R.id.durationTxt);

        final Spinner dynamicSpinner = (Spinner) findViewById(R.id.dynamic_spinner);

        String[] items = new String[] { "Running", "Jogging", "Walking", "Step Aerobics", "Elliptical", "Kayaking", "Tai Chi", "Yoga", "Pilates",
                "Dancing", "Swimming", "Tennis", "Volleyball", "Softball/Baseball", "Hiking", "Jumping Rope", "Stretching", "Squats", "Lunges", "Legs",
                "Lifting Weights", "Presses", "Push Ups", "Sit Ups", "Curl Ups", "Pull Ups"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, items);
        dynamicSpinner.setAdapter(adapter);
        dynamicSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                Log.v("item", (String) parent.getItemAtPosition(position));
                String text = parent.getItemAtPosition(position).toString();
                switch(text)
                {
                    case "Running":
                         milesPerHour = 5;
                        exerciseType = "Run";
                        break;
                    case "Jogging":
                         milesPerHour = 4;
                        exerciseType = "Run";
                        break;
                    case "Walking":
                         milesPerHour = 2;
                         exerciseType = "Run";
                        break;
                    case "Step Aerobics":
                        exerciseType = "Aerobics";
                        break;
                    case "Elliptical":
                        exerciseType = "Elliptical";
                        break;
                    case "Kayaking":
                        exerciseType = "Kayaking";
                        break;
                    case "Tai Chi":
                        exerciseType = "Tai Chi";
                        break;
                    case "Yoga":
                        exerciseType = "Yoga";
                        break;
                    case "Pilates":
                        exerciseType = "Pilates";
                        break;
                    case "Dancing":
                        exerciseType = "Dancing";
                        break;
                    case "Swimming":
                        exerciseType = "Swimming";
                        break;
                    case "Tennis":
                        exerciseType = "Tennis";
                        break;
                    case "Volleyball":
                        exerciseType = "Volleyball";
                        break;
                    case "Softball/Baseball":
                        exerciseType = "SoftBall/Baseball";
                        break;
                    case "Hiking":
                        exerciseType = "Hiking";
                        break;
                    case "Jumping Rope":
                        exerciseType = "Jumping Rope";
                        break;
                    case "Stretching":
                        exerciseType = "Other";
                        break;
                    case "Lifting Weights":
                        exerciseType = "Weights";
                        break;
                    case "Presses":
                        exerciseType = "Weights";
                        break;
                    case "Squats":
                        exerciseType = "Squats";
                        break;
                    case "Lunges":
                        exerciseType = "Lunges";
                        break;
                    case "Push Ups":
                        exerciseType = "Push Ups";
                        break;
                    case "Sit Ups":
                        exerciseType = "Push Ups";
                        break;
                    case "Curl Ups":
                        exerciseType = "Curl Ups";
                        break;
                    case "Pull Ups":
                        exerciseType = "Pull Ups";
                        break;
                }
        }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });
        calculateCalories();
       // viewAll();
        viewAll1();
        backButton = (Button) findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent back = new Intent(CaloriesActivity.this, HomeActivity.class);
                startActivity(back);
                finish();
            }

        });
        btnAddData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Global.setDailyCalories(Global.getDailyCalories() + burnedCalories);
                        Global.settotalcalories(Global.gettotalcalories() + burnedCalories);
                        postCalories();
                       //AddData();
                       //getAllData();
                    }
                }
        );
        clear.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                       clearData();

                    }
                }
        );

        noti = new NotificationHelper(this);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void sendNotification(int id, String title) {
        Notification.Builder nb = null;
        switch (id) {
            case NOTI_PRIMARY1:
                nb = noti.getNotification1(title, "Burned some calories? Keep it up!");
                break;
            case NOTI_PRIMARY2:
                nb = noti.getNotification1(title, "Let's burn them calories!");
                break;
        }
        if (nb != null) {
            noti.notify(id, nb);
        }
    }

    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * Turns off the pDialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    /**
     *
     */
    public void calculateCalories()
    {
        calcBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double weight = Double.parseDouble(weightTxt.getText().toString());
                double duration = Double.parseDouble(durationTxt.getText().toString());
                if (exerciseType.equals("Aerobics")) {
                    caloriesBurned = 3.34 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Elliptical")) {
                    caloriesBurned = 4.312 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Kayaking")) {
                    caloriesBurned = 2.264 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Tai Chi")) {
                    caloriesBurned = 1.92 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Yoga")) {
                    caloriesBurned = 2.08 * weight * (duration / 80);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Pilates")) {
                    caloriesBurned = 1.041 * weight * (duration / 80);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Dancing")) {
                    caloriesBurned = 2.88 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Swimming")) {
                    caloriesBurned = 4.538 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Tennis")) {
                    caloriesBurned = 1.92 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Volleyball")) {
                    caloriesBurned = 2.78 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("SoftBall/Baseball")) {
                    caloriesBurned = 2.27 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Hiking")) {
                    caloriesBurned = 2.68 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Jumping Rope")) {
                    caloriesBurned = 5 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Other")) {
                    caloriesBurned = 1.138 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Weights")) {
                    caloriesBurned = 1.44 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Squats")) {
                    caloriesBurned = .096 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Lunges")) {
                    caloriesBurned = 9.33 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Push Ups")) {
                    caloriesBurned = 8.56 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Curl Ups")) {
                    caloriesBurned = 7.29 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else if (exerciseType.equals("Pull Ups")) {
                    caloriesBurned = 9.95 * weight * (duration / 60);
                    Math.round(caloriesBurned);
                } else {
                    caloriesBurned = 0.53 * weight * milesPerHour * (duration / 60);
                    Math.round(caloriesBurned);
                }
                totalTextView.setText(Double.toString(Math.round(caloriesBurned)));
                burnedCalories = (int)Math.round(caloriesBurned);

                Handler mHandler = new Handler();
                mHandler.postDelayed(new Runnable() {

                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void run() {
                        sendNotification(NOTI_PRIMARY1, "Mush Puppies:");
                    }

                }, 1000L);

            }

        });
    }

    /**
     * Allows the user to view all of the total calories burned in form of a view list
     */


    /**
     * Works the same way as viewAll, except it shows all of the daily calories burned in form of a view list, sorted by date
     */
    public void viewAll1()
    {
        view1.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor data1 = myDb1.getData();
                       // ArrayList<String> listData1 = new ArrayList<>();
                        buffer1 = new String();
                        showProgressDialog();

                        Map<String, Object> params = new HashMap<String, Object>();
                        params.put("uid", Global.getId());



                        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, caloriesUrl, new JSONObject(params),
                                new Response.Listener<JSONObject>() {
                                    @Override
                                    public void onResponse(JSONObject response) {
                                        Log.d(TAG, response.toString());
                                        pDialog.dismiss();

                                        try {
                                            JSONArray temp = response.getJSONArray("dailylogs");
                                            for(int i = 0; i < temp.length(); i++) {
                                                JSONObject anothaone = (JSONObject) temp.get(i);
                                                String date = anothaone.getString("date");
                                                int dailyCals = anothaone.getInt("dailyCalories");
                                                buffer1 += "Calories Burned: "+ dailyCals + "Date: " + date + "\n";

                                            }
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }


                                    }
                                }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                VolleyLog.d(TAG, "Error: " + error.getMessage());
                                pDialog.dismiss();
                            }
                        }) {



                        };
                        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);

                        showMessage("Daily Calories Burned History: ",buffer1);
                    }
                }
        );
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {

            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                sendNotification(NOTI_PRIMARY2, "Mush Puppies:");
            }

        }, 1000L);



    }

    /**
     * This is the method designed to create the message shown in the daily total and cumulative calories burned lists
     * @param title The title of the message that appears when viewing the respective list
     * @param Message The message that appears when viewing the respective list
     */
    public void showMessage(String title,String Message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    private void getCalories() {

    }

    /**
     * Adds data onto the cumulative and daily log lists and stores the data into the databases for usage on the HomeActivity as well
     */
    public void AddData() {
        btnAddData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String date = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault()).format(new Date());
                        total = Double.valueOf(totalTextView.getText().toString());
                        dailyTotal = date + ":" + " " + total;

                       // myDb.addData(Double.toString(total));
                        //myDb1.addData1(dailyTotal);
                       // viewAll();
                        viewAll1();

                    }
                }
        );
    }

    /**
     * Gets all of the data from the Cumulative Calories Burned lists and makes it appear in form of a TextView for the user to see
     */
    public void getAllData()
    {
        Cursor data = myDb.getData();
        ArrayList<Double> listData = new ArrayList<>();
        while(data.moveToNext())
        {
                listData.add(Double.parseDouble(data.getString(1)));
        }
        for (double value : listData )
        {
            total += value;
           cumulativeView.setText(Double.toString(total));
        }

    }

    /**
     * Clears all data for both Calorie Lists
     */
    public void clearData()
    {
        clear.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDb.delete();
                        myDb1.delete();
                        total = 0;
                        cumulativeView.setText(Double.toString(total));
                    }
                }
        );
    }

    /**
     * This is the multiple tabs function that allows the user to navigate between the Profile Tab, Leaderboard Tab,
     * Home tab, Groups Tab, and Friends Tab.
     */
    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(CaloriesActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_leaderboard:
                    Intent leaderboardIntent = new Intent(CaloriesActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    finish();
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(CaloriesActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                    return true;
                case R.id.navigation_friends:
                    Intent friendsIntent = new Intent(CaloriesActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    finish();
                    return true;
            }
            return false;
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_mush_puppies, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void postCalories() {
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy");
        String date = df.format(c);

        Map<String, Object> params = new HashMap<>();
        params.put("uid", Global.getId());
        params.put("dailycalories", Global.getDailyCalories());
        params.put("date", date);
        params.put("totalcalories", Global.gettotalcalories());

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, postUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);

    }
}
