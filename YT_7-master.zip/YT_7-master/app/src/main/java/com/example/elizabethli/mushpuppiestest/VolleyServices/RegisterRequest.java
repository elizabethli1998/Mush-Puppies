package com.example.elizabethli.mushpuppiestest.VolleyServices;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by nathanoran on 4/14/18.
 */

public class RegisterRequest extends StringRequest {

    //GET VERSION
    public static final String REGISTER_REQUEST_URL = "http://localhost:8080/newuser/litdude2/swagger/Nathan/Oran/20/67/155"; //actual url here--I don't know the whole thing
    public RegisterRequest(Response.Listener<String> listener) {
        super(REGISTER_REQUEST_URL, listener,null);
    }

    /*//POST VERSION
    public static final String REGISTER_REQUEST_URL = "http://localhost:8080/register"; //actual url here--I don't know the whole thing
    public Map<String, String> params;

    public RegisterRequest(String username, String password, String firstname, String lastname, int age, int height, int weight, Response.Listener<String> listener) {
        super(Method.POST, REGISTER_REQUEST_URL, listener, null);
        params = new HashMap<>();
        params.put("username", username);
        params.put("password", password);
        params.put("firstName", firstname);
        params.put("lastName", lastname);
        params.put("age", age + "");
        params.put("height", height + "");
        params.put("weight", weight + "");
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
    */
}
