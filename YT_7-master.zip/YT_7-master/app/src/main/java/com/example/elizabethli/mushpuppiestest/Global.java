package com.example.elizabethli.mushpuppiestest;


import com.example.elizabethli.mushpuppiestest.VolleyServices.DailyLog;
import com.example.elizabethli.mushpuppiestest.VolleyServices.Exercise;
import com.example.elizabethli.mushpuppiestest.VolleyServices.Goals;

import java.util.ArrayList;

/**
 * Created by nathanoran on 4/10/18.
 */

public class Global {

    static private int uid;
    static private int uweight;
    static private int utotalcalories;
    static private int utotalsteps;
    static private String ulastname = "";
    static private String ufirstname = "";
    static private int uage;
    static private int uheight;
    static private ArrayList<Goals> ugoals = new ArrayList<>();
    static private ArrayList<DailyLog> udailyLog = new ArrayList<>();
    static private ArrayList<Exercise> uexercise = new ArrayList<>();
    static private String uusername;
    static private String upassword;
    static private int udailySteps;
    static private int udailyCalories;
    static private ArrayList<DailyLog> uSevenDaysData = new ArrayList<>();

    static private String [] allExercises = {"Walking (40 Minutes)", "Cycling (40 Minutes)", "Step Aerobics (40 Minutes)", "Elliptical Machine (50 Minutes)",
            "Kayaking (1 Hour)", "Tai Chi (1 Hour)", "Yoga (50 Minutes)", "Pilates (50 Minutes)", "Ballroom Dancing (50 minutes)",
            "Swimming Laps (30 Minutes)", "Brisk Walking (30 Minutes)", "Tennis Doubles (30 Minutes)", "Biking Under 10 mph (30 Minutes)",
            "Volleyball (30 Minutes)", "Softball/Baseball (30 Minutes)", "Jogging (30 Minutes)","Hiking (20 Minutes)", "Climbing Stairs (20 Minutes)",
            "Sprinting (20 Minutes)", "Jumping Rope (20 Minutes)", "Toe Touch (15 Reps)", "Walking Lunge (10 Reps/Leg)", "Butt Kick (25 Reps/Leg)",
            "High Knees (25 Reps/Leg)", "Trunk Twist (20 Reps/Side)","Full Squat (5 Sets, 10 reps)",
            "Hack Squat (3 Sets, 20 Reps)","Barbell Lunge (3 Sets, 10 Reps/Leg)", "Single Leg Deadlift (2 Sets, 10 Reps/Leg)",
            "Romanian Deadlift (3 Sets, 10 Reps)", "Leg Extension (3 Sets, 10 Reps)", "Leg Press (4 Sets, 10 Reps)",
            "Seated Legs Curl (4 Sets, 10 Reps)", "Lying Leg Curl (3 Sets, 12-15 Reps)", "Full Squat (5 Sets, 10 reps)",
            "Hack Squat (3 Sets, 20 Reps)","Barbell Lunge (3 Sets, 10 Reps/Leg)", "Single Leg Deadlift (2 Sets, 10 Reps/Leg)", "Romanian Deadlift (3 Sets, 10 Reps)",
            "Leg Extension (3 Sets, 10 Reps)", "Leg Press (4 Sets, 10 Reps)",
            "Seated Legs Curl (4 Sets, 10 Reps)", "Lying Leg Curl (3 Sets, 12-15 Reps)", "Bench Press (8 Sets, 8 Reps)", "Chin-Up (3 Sets, 6 Reps)",
            "Barbell High Pull (3 Sets, 8 Reps)", "Dips (3 Sets, 10-12 Reps)", "Dumbbell One-Arm Shoulder Press (3 Sets, 10 Reps)",
            "Standing Dumbbell Upright Row (3 Sets, 10 Reps)", "Incline Pushup (3 Sets, 8-15 Reps)",
            "Lying Dumbbell Tricep Extension (3 Sets, 8 Reps)", "Plank and Rotate (3 Sets, 10 Reps)", "Coordination Fly (2 Sets, 15 Reps)",
            "Standing Side Bend (2 Sets, 12 Reps)", "Dumbbell Side Bend (2 Sets, 15 Reps)", "Twisting Wood Chop with Medicine Ball (3 Sets, 15 Reps)",
            "Shoulder Press and Side Crunch (2 Sets, 15 Reps)", "Alphabet Abs (2 Sets, 15 Reps)", "Standing Twists (3 Sets, 30 Reps)"};


    public static ArrayList<DailyLog> getuSevenDaysData() {
        return uSevenDaysData;
    }

    public static void setuSevenDaysData(ArrayList<DailyLog> SevenDaysData) {
        uSevenDaysData = new ArrayList<>(SevenDaysData);
    }

    public static int getId() {
        return uid;
    }

    public static void setId(int id) {
        uid = id;
    }

    public static String getusername() {
        return uusername;
    }

    public static void setusername(String username) {uusername = username;}

    public static String getPassword() {
        return upassword;
    }

    public static void setPassword(String password) {
        upassword = password;
    }

    public static String [] getallExercises() {
      return allExercises;
    }

    public static int getWeight() {
        return uweight;
    }

    public static void setWeight(int weight) {uweight = weight;}

    public static int gettotalcalories() { return utotalcalories; }

    public static void settotalcalories(int totalcalories) {
        utotalcalories = totalcalories;
    }

    public static int gettotalsteps() {
        return utotalsteps;
    }

    public static void settotalsteps(int totalsteps) {
        utotalsteps = totalsteps;
    }

    public static String getlastname() {
        return ulastname;
    }

    public static void setlastname(String lastname) { ulastname= lastname;
    }
    public static String getfirstname() {
        return ufirstname;
    }

    public static void setfirstname(String firstname) {ufirstname = firstname;
    }
    public static int getage() {
        return uage;
    }

    public static void setage(int age) {
        uage = age;
    }

    public static int getheight() {
        return uheight;
    }

    public static void setheight(int height) { uheight = height;}


    public static ArrayList<Goals> getGoals() {return ugoals; }

    public static void setGoals(ArrayList<Goals> goals) {
        for(int i = 0; i < goals.size(); i++) {
            ugoals.add(goals.get(i));
        }

        //ugoals = new ArrayList<Goals>(goals);
    }

    public static ArrayList<DailyLog> getDailyLog() {
        return udailyLog;
    }

    public static void setDailyLog(ArrayList<DailyLog> dailylog) {
        udailyLog = new ArrayList<DailyLog>(dailylog);
    }

    public static ArrayList<Exercise> getUserExercises() {
        return uexercise;
    }

    public static void setUserExercises(ArrayList<Exercise> exercise) {
        uexercise = new ArrayList<Exercise>(exercise);
    }

    public static int getDailySteps() {
        return udailySteps;
    }

    public static void setDailySteps(int dailysteps) {udailySteps= dailysteps;}

    public static int getDailyCalories() {
        return udailyCalories;
    }

    public static void setDailyCalories(int dailyCalories) {udailyCalories = dailyCalories;}

    public static void clearGlobal(){
        uid = -1;
        uweight = -1;
        utotalcalories = -1;
        utotalsteps = -1;
        ulastname = "";
        ufirstname = "";
        uage = -1;
        uheight = -1;
        ugoals = new ArrayList<>();
        udailyLog = new ArrayList<>();
        uexercise = new ArrayList<>();
        uusername = "";
        upassword = "";
        udailySteps = -1;
        udailyCalories = -1;

    }

}
