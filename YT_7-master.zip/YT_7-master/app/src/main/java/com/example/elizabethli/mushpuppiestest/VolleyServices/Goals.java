package com.example.elizabethli.mushpuppiestest.VolleyServices;

/**
 * Created by Justin on 4/20/18.
 */

public class Goals {
    /**
     * Empty Goal constructor
     */
    public Goals() {

    }


    public Goals(int goalsId, int uid, String goal, int complete) {
        this.goalsId = goalsId;
        this.uid = uid;
        this.goal = goal;
        this.complete = complete;
    }


    private int goalsId;


    private int uid;

    private String goal;


    private int complete;


    public int getGoalsId() {
        return goalsId;
    }

    public void setGoalsId(int goalsId) {
        this.goalsId = goalsId;
    }



    public Integer getUID()
    {
        return this.uid;
    }

    /**
     * Method to get the goal
     * @return
     */
    public String getGoal() {
        return goal;
    }


    public int getComplete()
    {
        return this.complete;
    }



}
