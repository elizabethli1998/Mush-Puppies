package com.example.elizabethli.mushpuppiestest;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.android.volley.Request;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;

import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.elizabethli.mushpuppiestest.VolleyServices.DailyLog;
import com.example.elizabethli.mushpuppiestest.VolleyServices.Exercise;
import com.example.elizabethli.mushpuppiestest.VolleyServices.Goals;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import static com.example.elizabethli.mushpuppiestest.Global.setId;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * @author nathanoran
 */
public class LoginActivity extends AppCompatActivity {

    private Button btnSignIn;
    private Button btnRegisterAccount;

    private EditText edtUsername;
    private EditText edtPassword;

    private ProgressDialog pDialog;

    private static final String TAG = "LoginActivity";
    int userid;
    int weight;
    String lastname = "";
    String firstname = "";
    int age;
    int height;
    String success = "";
    ArrayList<Goals> allGoals = new ArrayList<Goals>();
    ArrayList<Exercise> exercises = new ArrayList<Exercise>();
    ArrayList<DailyLog> dailylog = new ArrayList<DailyLog>();
    int totalcalories;
    int totalsteps;
    String username = "";
    String password = "";
    int dailysteps;
    int dailycalories;


    String message;
    String postUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/login";
    String userUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/login";
    String goalUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/goalsonlogin/" + Global.getId();
    String dailyLogUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/dailylogsonlogin/" +Global.getId();
    String exerciseUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/exercisesonlogin/" + Global.getId();

    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";



    /**
     *This method constructs the entire Login Activity
     * it initializes the proper layout xml
     *
     * Then defines the EditText and Button objects
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);

        btnSignIn = (Button) findViewById(R.id.btnSignIn);
        btnRegisterAccount = (Button) findViewById(R.id.btnRegisterAccount);

        edtUsername = (EditText) findViewById(R.id.entUserName);
        edtPassword = (EditText) findViewById(R.id.entPassword);



        btnRegisterAccount.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent registerIntent = new Intent(LoginActivity.this, RegisterActivity.class);
                registerIntent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                registerIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                registerIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(registerIntent);
                finish();
            }

        });

        btnSignIn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){


                postJsonArrayRequest();
                if(success.equals("true")) {
                    Intent homeIntent = new Intent(LoginActivity.this, HomeActivity.class);
                    showProgressDialog();
                    //getGoals();
                    //getExercises();
                    //getDailyLog();
                    Global.setDailyLog(dailylog);
                    Global.setUserExercises(exercises);
                    startActivity(homeIntent);
                    finish();
                    hideProgressDialog();
                }

            }

        });
    }


    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * Turns off the pDialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    private void postJsonArrayRequest() {
        showProgressDialog();
        Map<String, String> params = new HashMap<String, String>();
        params.put("username", edtUsername.getText().toString());
        params.put("password", edtPassword.getText().toString());



        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, postUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        try {

                            JSONObject user = response;
                            if (user.getString("success").equals("true")) {
                                success = "true";
                                userid = user.getInt("uid");
                                weight = user.getInt("weight");
                                firstname = user.getString("firstname");
                                lastname = user.getString("lastname");
                                totalsteps = user.getInt("totalsteps");
                                totalcalories = user.getInt("totalcalories");
                                age = user.getInt("age");
                                height= user.getInt("height");
                                username = user.getString("username");
                                password = user.getString("password");

                                JSONArray tempGoals = user.getJSONArray("goals");
                                JSONArray tempExercise = user.getJSONArray("exercises");
                                JSONArray tempDailyLogs = user.getJSONArray("dailylogs");

//                                try {
//
//                                    for(int i = 0; i < tempGoals.length(); i++) {
//                                        JSONObject temp = (JSONObject)tempGoals.get(i);
//
//                                        int uid = temp.getInt("uid");
//                                        String goalName = temp.getString("goal");
//                                        int complete = temp.getInt("complete");
//                                        int goalsId = temp.getInt("goalsId");
//
//                                        Goals goal = new Goals(goalsId, uid, goalName, complete);
//                                        allGoals.add(goal);
//
//                                    }
//
//                                    Global.setGoals(allGoals);
//
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                    Toast.makeText(getApplicationContext(),
//                                            "Error: " + e.getMessage(),
//                                            Toast.LENGTH_LONG).show();
//
//                                }

                                try {

                                    for(int i = 0; i < tempExercise.length(); i++) {
                                        JSONObject temp = (JSONObject)tempExercise.get(i);
                                        int uid = temp.getInt("uid");
                                        int exerciseId = temp.getInt("androidId");
                                        String date = temp.getString("date");

                                        Exercise exercise = new Exercise(uid, exerciseId, date);
                                        exercises.add(exercise);

                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Toast.makeText(getApplicationContext(),
                                            "Error: " + e.getMessage(),
                                            Toast.LENGTH_LONG).show();

                                }

                                try {

                                    for(int i = 0; i < tempDailyLogs.length(); i++) {
                                        Date c = Calendar.getInstance().getTime();

                                        SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy");
                                        String date = df.format(c);

                                        JSONObject temp = (JSONObject)tempDailyLogs.get(i);
                                        int uid = temp.getInt("uid");
                                        String newdate = temp.getString("date");
                                        dailysteps = temp.getInt("dailySteps");
                                        dailycalories = temp.getInt("dailyCalories");

                                        if(newdate.equals(date)) {
                                            DailyLog tempdaily = new DailyLog(uid, newdate, dailysteps, dailycalories);
                                            dailylog.add(tempdaily);
                                        }
                                        else {
                                            DailyLog tempdaily = new DailyLog(uid, newdate, 0, 0);
                                            dailylog.add(tempdaily);
                                        }
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Toast.makeText(getApplicationContext(),
                                            "Error: " + e.getMessage(),
                                            Toast.LENGTH_LONG).show();

                                }

                                Global.setId(userid);
                                Global.setWeight(weight);
                                Global.setfirstname(firstname);
                                Global.setlastname(lastname);
                                Global.settotalsteps(totalsteps);
                                Global.settotalcalories(totalcalories);
                                Global.setage(age);
                                Global.setheight(height);
                                Global.settotalcalories(totalcalories);
                                Global.settotalsteps(totalsteps);
                                Global.setPassword(password);
                                Global.setusername(username);
                                Global.setDailySteps(dailysteps);
                                Global.setDailyCalories(dailycalories);

                            }
                            else {
                                message = user.getString("message");
                                success = "false";
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
                            }



                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),
                                    "Error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();

                        }

                        pDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();

            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);


    }

    private void getGoals() {
        showProgressDialog();
        JsonArrayRequest req = new JsonArrayRequest(goalUrl,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {


                        Log.d(TAG, response.toString());
                        try {

                            for(int i = 0; i < response.length(); i++) {
                                JSONObject temp = (JSONObject)response.get(i);
                                int uid = temp.getInt("uid");
                                String goalName = temp.getString("goal");
                                int complete = temp.getInt("complete");
                                int goalsId = temp.getInt("goalsId");

                               Goals goal = new Goals(goalsId, uid, goalName, complete);
                               allGoals.add(goal);

                            }

                            Global.setGoals(allGoals);







                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),
                                    "Error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();

                        }


                        hideProgressDialog();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                hideProgressDialog();
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(req);
    }

    private void getDailyLog() {

        showProgressDialog();
        JsonArrayRequest req = new JsonArrayRequest(dailyLogUrl,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {


                        Log.d(TAG, response.toString());
                        try {

                            for(int i = 0; i < response.length(); i++) {
                                JSONObject temp = (JSONObject)response.get(i);
                                int uid = temp.getInt("uid");
                                String date = temp.getString("date");
                                int dailysteps = temp.getInt("dailysteps");
                                int dailycalories = temp.getInt("dailycalories");

                                DailyLog tempdaily = new DailyLog(uid, date, dailysteps, dailycalories);
                                dailylog.add(tempdaily);


                            }







                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),
                                    "Error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();

                        }


                        hideProgressDialog();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                hideProgressDialog();
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(req);


    }

    private void getExercises() {
        showProgressDialog();
        JsonArrayRequest req = new JsonArrayRequest(exerciseUrl,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {


                        Log.d(TAG, response.toString());
                        try {

                            for(int i = 0; i < response.length(); i++) {
                                JSONObject temp = (JSONObject)response.get(i);
                                int uid = temp.getInt("uid");
                                int exerciseId = temp.getInt("androidId");
                                String date = temp.getString("date");

                                Exercise exercise = new Exercise(uid, exerciseId, date);
                                exercises.add(exercise);

                            }







                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),
                                    "Error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();

                        }


                        hideProgressDialog();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                hideProgressDialog();
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(req);
    }

    private void makeJsonArrayRequest() {
        showProgressDialog();
        JsonArrayRequest req = new JsonArrayRequest(userUrl,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {


                        Log.d(TAG, response.toString());
                        try {

                            JSONObject user = (JSONObject)response.get(0);
                            if (user.getString("success").equals("true")) {
                                success = "true";
                                userid = user.getInt("uid");
                                weight = user.getInt("weight");
                                firstname = user.getString("firstname");
                                lastname = user.getString("lastname");
                                totalsteps = user.getInt("totalsteps");
                                totalcalories = user.getInt("totalcalories");
                                age = user.getInt("age");
                                height= user.getInt("height");
                                password = user.getString("password");

                                Global.setId(userid);
                                Global.setWeight(weight);
                                Global.setfirstname(firstname);
                                Global.setlastname(lastname);
                                Global.settotalsteps(totalsteps);
                                Global.settotalcalories(totalcalories);
                                Global.setage(age);
                                Global.setheight(height);

                            }
                            else {
                                message = user.getString("message");
                                success = "false";
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
                            }







                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(),
                                    "Error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();

                        }


                        hideProgressDialog();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                hideProgressDialog();
            }
        });

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(req);
    }


}
