package com.example.elizabethli.mushpuppiestest;

/**
 * Created by meghnavaidya on 3/28/18.
 */

import java.util.Calendar;

public abstract class Util {

    /**
     * Used in database to get the current date to be able to get daily steps
     * @return - date of the current day
     */
    public static long getToday() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(System.currentTimeMillis());
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

}
