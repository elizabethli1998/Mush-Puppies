package com.example.elizabethli.mushpuppiestest;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by elizabethli on 4/21/18.
 */

public class FriendRequestActivity extends AppCompatActivity {
    private TextView mTextMessage;
    String deleteUser = "";
    String confirmUser = "";
    String friendMessage = "";
    private String getRequestUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/myrequests";
    private String acceptUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/acceptfriend";
    private String denyUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/rejectfriend";
    private Button backButton;
    private Button confirmRequest;
    private Button deleteRequest;
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";
    private ProgressDialog pDialog;
    private static final String TAG = "FriendsActivity";
    ArrayList<String> listItems=new ArrayList<String>();
    ListView friendsList;
    ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_request);

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);


    friendsList = (ListView) findViewById(R.id.list_request);


        listItems = new ArrayList<>();
        adapter=new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                listItems);
        getRequests();




        //initialization for the bottom navigation stuff
        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


        backButton= (Button) findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(FriendRequestActivity.this, FriendsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                overridePendingTransition(0, 0);
                startActivity(intent);

            }

        });

        deleteRequest = (Button) findViewById(R.id.deleteRequest);
        final EditText deleteText = new EditText(this);
        final AlertDialog.Builder dialog1 = new AlertDialog.Builder(this);
        deleteRequest.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                dialog1.setTitle("Delete Request");
                dialog1.setMessage("Enter the username that you wish to delete: ");
                dialog1.setView(deleteText)
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogue, int which) {
                                deleteUser = String.valueOf(deleteText.getText());
                                deleteFriendRequest(deleteUser);
                                getRequests();
                                Toast toast;

                                //basic modal to check if a user exists and toasts the proper response
                                toast = Toast.makeText(getApplicationContext(), friendMessage, Toast.LENGTH_SHORT);


                                toast.setGravity(Gravity.BOTTOM, 0, 200);
                                toast.show();

                               //Insert delete User stuff here

                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create();
                dialog1.show();
            }
        });


        confirmRequest = (Button) findViewById(R.id.confirmRequest);
        final EditText confirmText = new EditText(this);
        final AlertDialog.Builder dialog2 = new AlertDialog.Builder(this);
        confirmRequest.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                dialog2.setTitle("Confirm Request");
                dialog2.setMessage("Enter the username that you want to be your friend: ");
                dialog2.setView(confirmText)
                        .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogue, int which) {
                                confirmUser = String.valueOf(confirmText.getText());
                                confirmFriendRequest(confirmUser);
                                getRequests();
                                Toast toast;

                                //basic modal to check if a user exists and toasts the proper response
                                toast = Toast.makeText(getApplicationContext(), friendMessage, Toast.LENGTH_SHORT);


                                toast.setGravity(Gravity.BOTTOM, 0, 200);
                                toast.show();

                                //Insert confirm User stuff here

                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create();
                dialog2.show();
            }
        });


        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(3);
        menuItem.setChecked(true);
    }

    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * delete dialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }



    /**
     * This is the multiple tabs function that allows the user to navigate between the Profile Tab, Leaderboard Tab,
     * Home tab, Groups Tab, and Friends Tab.
     */
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(FriendRequestActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_leaderboard:
                    Intent leaderboardIntent = new Intent(FriendRequestActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    finish();
                    return true;
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_friends:
                    Intent friendsIntent = new Intent(FriendRequestActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    finish();
                    return true;
            }
            return false;
        }
    };

    private void getRequests() {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("uid", Global.getId());


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, getRequestUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                        try {
                            JSONArray temp = response.getJSONArray("requests");
                            for(int i = 0; i < temp.length(); i++) {
                                JSONObject friend = (JSONObject) temp.get(i);
                                String username = friend.getString("username");
                                listItems.add(username);
                                //allFriends.add(username);
                            }

                            //friendsList.setAdapter(adapter);
                            friendsList.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }


    private void confirmFriendRequest(String userToFind) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("uid", Global.getId());
        params.put("username", userToFind);


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, acceptUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        getRequests();

                        pDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();

            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }

    private void deleteFriendRequest(String userToFind) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("uid", Global.getId());
        params.put("username", userToFind);


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, denyUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        getRequests();


                        pDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();

            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }
}

