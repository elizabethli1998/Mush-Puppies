package com.example.elizabethli.mushpuppiestest.ExerciseDatabase;

/**
 * @author Elizabeth Li
 * This is the database for all exercises that are input into the app through sqlite
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.database.Cursor;




public class ExerciseDatabaseHelper extends SQLiteOpenHelper
{
    private static final String TAG = "ExerciseDatabaseHelper";
    private static final String TABLE_NAME = "exercise_table";
    private static final String COL1 = "ID";
    private static final String COL2 = "exercise";
    private SQLiteDatabase db;

    public ExerciseDatabaseHelper(Context context)
    {
        super(context, TABLE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String createTable = "Create Table " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL2 + " TEXT)";
        db.execSQL(createTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1)
    {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    /**
     * Adds data to the database
     * @param item Adds string to database
     * @return boolean for adding data
     */
    public boolean addData(String item)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, item);
        Log.d(TAG, "addData: Adding " + item + " to " + TABLE_NAME);
        long result = db.insert(TABLE_NAME, null, contentValues);
        if(result == -1)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    /**
     * Deletes all entries from database
     */
    public void deleteAll()
    {
        SQLiteDatabase db = this.getWritableDatabase();
       //db.delete(TABLE_NAME,COL2 + "=?", new String[] {String.valueOf(id)});
        db.delete(TABLE_NAME, null, null);
       db.close();


        /**
         * Deletes entry from database
         */
    }
    public void deleteData (long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, "exercise = ?",new String[] {String.valueOf(id)});
    }
    /**
     * Grabs data from database
     * @return data
     */

    public Cursor getData()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(query, null);
        return data;
    }


}
