package com.example.elizabethli.mushpuppiestest;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.elizabethli.mushpuppiestest.VolleyServices.RegisterRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author nathanoran
 */
public class RegisterActivity extends AppCompatActivity {

    private EditText firstName;
    private EditText lastName;
    private EditText userName;
    private EditText passWord;
    private EditText conFirm;
    private EditText htFt;
    private EditText htIn;
    private EditText Age;
    private EditText Weight;

    private Button btnRegister;
    private String postUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/register";
    private ProgressDialog pDialog;
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";
    private static final String TAG = "RegisterActivity";


    /**
     * This method constructs the entire Register Activity
     * it initializes the proper layout xml
     *
     * Then defines the EditText and Button objects
     *
     * It also defines the Click Listener for the button
     * which creates and sends a Volley request to create a new user on the database and automatically login to the app
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);

        firstName = (EditText) findViewById(R.id.edtFirstName);
        lastName = (EditText) findViewById(R.id.edtLastName);
        userName = (EditText) findViewById(R.id.edtUsername);
        passWord = (EditText) findViewById(R.id.edtPassword);
        passWord.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        conFirm =(EditText) findViewById(R.id.edtConfirmPassword);
        htFt = (EditText) findViewById(R.id.edtFeet);
        htIn = (EditText) findViewById(R.id.edtInch);
        Age = (EditText) findViewById(R.id.edtYears);
        Weight = (EditText) findViewById(R.id.edtPounds);

        btnRegister = (Button) findViewById(R.id.btnCreate);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String password = passWord.getText().toString();

                if(password.equals(conFirm.getText().toString())) {

                    postJsonObj();
                    Intent homeIntent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(homeIntent);
                    finish();

                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
                    builder.setMessage("Passwords don't match")
                            .setNegativeButton("Retry", null)
                            .create()
                            .show();
                }
            }
        });


    }

    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * hides dialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    private void postJsonObj() {
        showProgressDialog();

        Map<String, String> params = new HashMap<String, String>();
        params.put("firstname", firstName.getText().toString());
        params.put("lastname", lastName.getText().toString());
        params.put("username", userName.getText().toString());
        params.put("password", passWord.getText().toString());
        int heightft = Integer.parseInt(htFt.getText().toString()) * 12;
        int ftheight = Integer.parseInt(htIn.getText().toString());
        int total = heightft + ftheight;
        params.put("height", Integer.toString(total));
        params.put("age", (Age.getText().toString()));
        params.put("weight", Weight.getText().toString());


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, postUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {





        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }
}