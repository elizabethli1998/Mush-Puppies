package com.example.elizabethli.mushpuppiestest;
/**
 * @author Elizabeth Li, Justin Lee
 * This Activity holds the lists of all of the Cardio Exercises available for the User to add onto the
 * exercise lists in form of a check list, that when checked, will add onto the exercise list on the homepage
 */

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Button;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.elizabethli.mushpuppiestest.ExerciseDatabase.ExerciseDatabaseHelper;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * This activity provides all of the cardio exercises in form of a checklist, with each exercise being
 * a checkable item. When checked, it will add the respective checked item onto the exercise list
 */

public class CardioActivity extends AppCompatActivity {

    Button backButton;
    Button customButton1;
    private TextView mTextMessage;
    private static final String TAG = "CardioActivity";
    private String postUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/addexercise";
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";
    private ProgressDialog pDialog;
    int index;
    private  String [] allExercises = Global.getallExercises();

    ExerciseDatabaseHelper mDatabaseHelper;

    ArrayList<String> selectedItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardio);
        mDatabaseHelper = new ExerciseDatabaseHelper(this);

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);

        ListView checked = (ListView) findViewById(R.id.checkable_list);
        checked.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);



        final ArrayList<String> items = new ArrayList<String>();
        items.add("Walking (40 Minutes)");
        items.add("Cycling (40 Minutes)");
        items.add("Step Aerobics (40 Minutes)");
        items.add("Elliptical Machine (50 Minutes)");
        items.add("Kayaking (1 Hour)");
        items.add("Tai Chi (1 Hour)");
        items.add("Yoga (50 Minutes)");
        items.add("Pilates (50 Minutes)");
        items.add("Ballroom Dancing (50 minutes)");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.item_cardio_list, R.id.text_workout,items);
        checked.setAdapter(adapter);
        checked.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedItem = ((TextView)view).getText().toString();

                if(selectedItems.contains(selectedItem))
                {

                    selectedItems.remove(selectedItem);
                }
                else
                {
                    selectedItems.add(selectedItem);
                    index = findIndex(allExercises, selectedItem);
                    try {
                        postJsonObj(index);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    //AddData(selectedItem);

                }
            }
        });
        ListView checked2 = (ListView) findViewById(R.id.medium_intensity_list);
        checked2.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        String[] items2 = {"Swimming Laps (30 Minutes)", "Brisk Walking (30 Minutes)", "Tennis Doubles (30 Minutes)", "Biking Under 10 mph (30 Minutes)",
                "Volleyball (30 Minutes)", "Softball/Baseball (30 Minutes)", "Jogging (30 Minutes)"};
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, R.layout.item_cardio_list, R.id.text_workout,items2);
        checked2.setAdapter(adapter2);
        checked2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedItem = ((TextView)view).getText().toString();

                if(selectedItems.contains(selectedItem))
                {
                    selectedItems.remove(selectedItem); //This unchecks the item
                }
                else
                {
                    selectedItems.add(selectedItem);
                    index = findIndex(allExercises, selectedItem);
                    try {
                        postJsonObj(index);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    // AddData(selectedItem);

                }
            }
        });

        ListView checked3 = (ListView) findViewById(R.id.high_intensity_list);
        checked3.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        String[] items3 = {"Hiking (20 Minutes)", "Climbing Stairs (20 Minutes)", "Sprinting (20 Minutes)", "Jumping Rope (20 Minutes)",
        "Toe Touch (15 Reps)", "Walking Lunge (10 Reps/Leg)", "Butt Kick (25 Reps/Leg)", "High Knees (25 Reps/Leg)", "Trunk Twist (20 Reps/Side)"};
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, R.layout.item_cardio_list, R.id.text_workout,items3);
        checked3.setAdapter(adapter3);
        checked3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String selectedItem = ((TextView)view).getText().toString();

                if(selectedItems.contains(selectedItem))
                {
                    selectedItems.remove(selectedItem); //This unchecks the item
                }
                else
                {
                    selectedItems.add(selectedItem);
                    index = findIndex(allExercises, selectedItem);
                    try {
                        postJsonObj(index);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    // AddData(selectedItem);

                }
            }
        });


        backButton = (Button) findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent addExerciseIntent = new Intent(CardioActivity.this, AddExerciseActivity.class);
                startActivity(addExerciseIntent);
                finish();
            }

        });

        //initialization for the bottom navigation stuff
        mTextMessage = (TextView) findViewById(R.id.defaultNavTextView);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);


    }

    /**
     * creates dialog
     */
    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * deletes dialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    /**
     * Adds data onto the exercise list and databases.
     * Will also notify the User that the exercise has been added.
     * @param newEntry the exercise that is checked on the CardioActivity and added onto the databases
     */
    public void AddData(String newEntry)
    {
        boolean insertData = mDatabaseHelper.addData(newEntry);

        if(insertData)
        {
            Toast.makeText(getApplicationContext(),"Updated Exercise List!",Toast.LENGTH_SHORT).show();

        }
    }

    /**
     * This is the multiple tabs function that allows the user to navigate between the Profile Tab, Leaderboard Tab,
     * Home tab, Groups Tab, and Friends Tab.
     */

    //This is the bottom navigation view
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(CardioActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;

                case R.id.navigation_leaderboard:
                   // mTextMessage.setText(R.string.title_leaderboard);
                    Intent leaderboardIntent = new Intent(CardioActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(CardioActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    return true;

                case R.id.navigation_friends:
                 //   mTextMessage.setText(R.string.title_friends);
                    Intent friendsIntent = new Intent(CardioActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    return true;
            }
            return false;
        }
    };
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_mush_puppies, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Creates a JsonObjectRequest where it will send out the uid, the exerciseId (index), and the date.
     * It will then add this request to the queue.
     *
     * @param index
     * index that would be stored
     * @throws JSONException
     */
    private void postJsonObj(int index) throws JSONException {
        showProgressDialog();
        Date c = Calendar.getInstance().getTime();

        SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy");
        String date = df.format(c);

        Map<String, String> params = new HashMap<String, String>();
        params.put("uid", Integer.toString(Global.getId()));
        params.put("androidId", Integer.toString(index));
        params.put("date", date);



        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, postUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }

    /**
     * finds the index of item in items array
     * @param items
     * array of all exercises
     * @param item
     * exercise wanting to be put into the JSON Request
     * @return
     * index of item
     */
    public int findIndex(String [] items, String item) {
        for(int i = 0; i < items.length; i++) {
            if(items[i].equals(item)) {
                return i;
            }
        }
        return -1;
    }

}