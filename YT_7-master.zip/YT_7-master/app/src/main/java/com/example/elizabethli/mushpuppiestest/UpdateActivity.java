package com.example.elizabethli.mushpuppiestest;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

/**
 * @author nathanoran
 * @author justinlee
 */
public class UpdateActivity extends AppCompatActivity{

    private Button btnCancel;
    private Button btnSave;
    private Button btnDeleteUser;
    private Button btnUpdateDailySteps;

    private EditText userName;
    private EditText firstName;
    private EditText lastName;
    private EditText feet;
    private EditText inches;
    private EditText age;
    private EditText weight;
    private EditText totalSteps;
    private ProgressDialog pDialog;
    private String updateUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/updateuser";
    private static final String TAG = "UpdateActivity";
    private String deleteUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/userdelete";
    private String stepUrl = "http://proj-309-yt-7.cs.iastate.edu:8080/logsteps";
    private int feetHeight;
    private int inchHeight;

    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";

    /**
     * This method constructs the entire Update Activity
     * it initializes the proper layout xml
     *
     * Then defines the EditText and Button objects
     *
     * Also defines CLick Listeners for all buttons
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...");
        pDialog.setCancelable(false);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);

        userName = (EditText) findViewById(R.id.edtUsername);
        firstName = (EditText) findViewById(R.id.edtFirstName);
        lastName = (EditText) findViewById(R.id.edtLastName);
        feet = (EditText) findViewById(R.id.edtFeet);
        inches = (EditText) findViewById(R.id.edtInch);
        age = (EditText) findViewById(R.id.edtYears);
        weight = (EditText) findViewById(R.id.edtPounds);

        //this is where the json request needs to happen I think





        userName.setText(Global.getusername());
        firstName.setText(Global.getfirstname());
        lastName.setText(Global.getlastname());
        feet.setText(Integer.toString(Global.getheight() / 12));
        inches.setText(Integer.toString(Global.getheight() %12));
        age.setText(Integer.toString(Global.getage()));
        weight.setText(Integer.toString(Global.getWeight()));

        btnUpdateDailySteps = (Button) findViewById(R.id.dailyStepButton);
        btnUpdateDailySteps.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                updateDailySteps();
                Toast.makeText(getApplicationContext(),
                        "Updated Daily Steps!",
                        Toast.LENGTH_LONG).show();

            }
        });
        btnDeleteUser = (Button) findViewById(R.id.deleteButton);
        btnDeleteUser.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent loginIntent = new Intent(UpdateActivity.this, LoginActivity.class);
                startActivity(loginIntent);
                finish();

                deleteUser();
            }
        });

        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent saveIntent = new Intent(UpdateActivity.this, ProfileActivity.class);
                startActivity(saveIntent);
                finish();

            }
        });

        btnSave = (Button) findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                updateUser();

                Intent saveIntent = new Intent(UpdateActivity.this, ProfileActivity.class);
                startActivity(saveIntent);
                finish();




            }
        });
    }

    /**
     * Turns on pDialog
     */
    private void showProgressDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /**
     * Turns off pDialog
     */
    private void hideProgressDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    /**
     * This is the bottom navigation view
     *
     * Starts the corresponding Android Activity based on the menu item selected.
     */
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            //The default activity simply changes the text in a text view when different nav buttons/tabs are selected
            //I think there's a setContent function or something this will allow us to have multiple sublayouts and switch between them based on the nav buttons rather than simply updating text
            //I'm gonna try to use Lizzy's content_mush_puppies.xml for a proof of concept
            switch (item.getItemId()) {
                case R.id.navigation_profile:
                    Intent profileIntent = new Intent(UpdateActivity.this, ProfileActivity.class);
                    startActivity(profileIntent);
                    finish();
                    return true;
                case R.id.navigation_leaderboard:
                    Intent leaderboardIntent = new Intent(UpdateActivity.this, LeaderboardActivity.class);
                    startActivity(leaderboardIntent);
                    finish();
                    return true;
                case R.id.navigation_home:
                    Intent homeIntent = new Intent(UpdateActivity.this, HomeActivity.class);
                    startActivity(homeIntent);
                    finish();
                    return true;
                case R.id.navigation_friends:
                    Intent friendsIntent = new Intent(UpdateActivity.this, FriendsActivity.class);
                    startActivity(friendsIntent);
                    finish();
                    return true;
            }
            return false;
        }
    };

    /**
     *Creates and sends JSON Volley request to update the user's row in the database table
     */
    private void deleteUser() {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("uid", Global.getId());


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, deleteUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);

    }
    private void updateUser() {

        Map<String, Object> params = new HashMap<String, Object>();
        params.put("uid", Global.getId());
        params.put("username", userName.getText().toString());
        params.put("firstname", firstName.getText().toString());
        params.put("lastname", lastName.getText().toString());
        feetHeight = Integer.parseInt(feet.getText().toString());
        inchHeight = Integer.parseInt(inches.getText().toString());
        params.put("height", ((12*feetHeight) + inchHeight));
        params.put("weight", Integer.parseInt(weight.getText().toString()));
        params.put("age", Integer.parseInt(age.getText().toString()));


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, updateUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {


        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);
    }

    private void updateDailySteps() {
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy");
        String date = df.format(c);

        Map<String, Object> params = new HashMap<>();
        params.put("uid", Global.getId());
        params.put("dailysteps", Global.getDailySteps());
        params.put("date", date);
        params.put("totalsteps", Global.gettotalsteps());

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, stepUrl, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                        pDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {



        };
        AppController.getInstance().addToRequestQueue(jsonObjReq, tag_json_obj);

    }
}
