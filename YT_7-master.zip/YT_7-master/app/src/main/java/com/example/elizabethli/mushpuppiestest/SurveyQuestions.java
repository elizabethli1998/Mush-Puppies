package com.example.elizabethli.mushpuppiestest;

/**
 * Created by elizabethli on 4/14/18.
 */

public class SurveyQuestions {

    public String questions[] =
            {
                "How much time are you willing to workout?",
                "How many times a week are you willing to workout?",
                "Do you prefer working out alone or in a group?",
                "Do you prefer working out indoors or outdoors?",
                "How intense are you when it comes to exercise?",
                "Which of the following is the closest to what you want to achieve with exercising?",
                "How in shape are you at the moment?",
                "Which of the following sounds more like you?",
                "What would be your focus area for exercise?"
            };

    private String choice[][] =
    {
            {"30 minutes or less", "30 minutes to an hour", "1 hour+", "2 hours+"},
            {"2x a week or less", "3x a week", "4x a week", "5x a week or more"},
            {"Alone", "Either way is fine", "Group", " "},
            {"Indoors", "Both", "Outdoors", " "},
            {"Not intense at all", "Moderately intense", "Intense", "Very Intense"},
            {"Better mind and overall health", "Be fit overall", "Lose weight/fat", "Bulk up"},
            {"Bad shape", "Fair shape", "Good shape", "Great shape"},
            {"I want to keep things simple, but still be healthy. I am not looking for something that is too intense.",
            "I want to look good, burn calories, increase energy, increase metabolism, and improve my heart health",
            "I want to tone up, burn fat, reduce risk of diabetes, prevent back pain, and become stronger overall!",
                   "I want to be fit as possible and am willing to take on anything that is the most intense"},
            {"Waist", "Arms", "Legs", "Make large muscular gains, such as abs, and be toned overall"}

    };

    private String zeroPoints[] = {"30 minutes or less", "2x a week or less", "Alone", "Indoors", "Not intense at all",
            "Better mind and overall health", "Bad shape", "I want to keep things simple, but still be healthy. I am not looking for something that is too intense.",
            "Waist"};

    private String onePoint[] = {"30 minutes to an hour", "3x a week", "Either way is fine", "Both",  "Moderately intense",
            "Be fit overall", "Fair shape", "I want to look good, burn calories, increase energy, increase metabolism, and improve my heart health",
            "Arms"};
    private String twoPoints[] = {"1 hour+", "4x a week", "Group", "Outdoors", "Intense", "Lose weight/fat",
            "Good shape", "I want to tone up, burn fat, reduce risk of diabetes, prevent back pain, and become stronger overall!",
            "Legs"};
    private String threePoints[] = {"2 hours+","5x a week or more", " ", " ", "Very Intense","Bulk up",
            "Great shape",  "I want to be fit as possible and am willing to take on anything that is the most intense",
            "Make large muscular gains, such as abs, and be toned overall"};

    public String getQuestion(int a)
    {
        String question = questions[a];
        return question;
    }

    public String getChoice1(int a)
    {
        String choose = choice[a][0];
        return choose;

    }

    public String getChoice2(int a)
    {
        String choose = choice[a][1];
        return choose;

    }
    public String getChoice3(int a)
    {
        String choose = choice[a][2];
        return choose;

    }
    public String getChoice4(int a)
    {
        String choose = choice[a][3];
        return choose;

    }

    public String allocateZeroPoints(int a)
    {
        String answer = zeroPoints[a];
        return answer;
    }

    public String allocateOnePoint(int a)
    {
        String answer = onePoint[a];
        return answer;
    }

    public String allocateTwoPoints(int a)
    {
        String answer = twoPoints[a];
        return answer;
    }

    public String allocateThreePoints(int a)
    {
        String answer = threePoints[a];
        return answer;
    }



}
