package com.example.elizabethli.mushpuppiestest;

/**
 * @author Elizabeth Li
 * The sample Notify message that is provided to notify the User to do their exercises and whatever else is planned
 * on MushPuppies
 */

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Toast;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import static android.content.Context.NOTIFICATION_SERVICE;

/**
 * Created by elizabethli on 3/22/18.
 */

/**
 * The message that is provided in form of a toast that appears every 24 hours to remind the User to do their exercises
 */
//Note: this is only here just to prove that the alarm reminder thing works as a simple feature.
    //If there is time, more will be added.
public class NotifyService extends BroadcastReceiver
{
    public void onReceive(Context context, Intent intent)
    {


         String cal =  new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
         String date = "2018-04-25";
         String date1 = "2018-04-22";
         String date2 = "2018-04-23";
         String date3 = "2018-04-24";


        if(cal.equals(date))
        {
            Toast.makeText(context, "Do at least three of your daily exercises!", Toast.LENGTH_LONG).show();
        }

        else if(cal.equals(date1))
        {
            Toast.makeText(context, "Lose/Gain 2 lbs!", Toast.LENGTH_LONG).show();
        }
        else if(cal.equals(date3))
        {
            Toast.makeText(context, "Complete 3 goals!", Toast.LENGTH_LONG).show();
        }
       else if (cal.equals(date2))
        {
            Toast.makeText(context, "Do 2 Lifting Exercises today!", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(context, "Burn at least 300 calories today!", Toast.LENGTH_LONG).show();

        }
    }
}
