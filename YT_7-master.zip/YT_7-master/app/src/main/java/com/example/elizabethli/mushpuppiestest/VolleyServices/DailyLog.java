package com.example.elizabethli.mushpuppiestest.VolleyServices;

import java.sql.Date;

/**
 * Created by Justin on 4/20/18.
 */

public class DailyLog {

    public DailyLog()
    {
    }

    public DailyLog(int uid, String date, int dailysteps,
                    int dailycalories)
    {
        super();
        this.uid = uid;
        this.date = date;
        this.dailysteps = dailysteps;
        this.dailycalories = dailycalories;
    }

    private int dailylogId;

    private int uid;

    private String date;

    private int dailysteps;

    private int dailycalories;

    public int getDailyLogID()

    {
        return this.dailylogId;
    }


    public int getUID()
    {
        return this.uid;
    }


    public String getDate()
    {
        return this.date;
    }


    public int getDailySteps()
    {
        return this.dailysteps;
    }


    public int getDailyCalories()
    {
        return this.dailycalories;
    }


}
