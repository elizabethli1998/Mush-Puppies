package com.example.elizabethli.mushpuppiestest.sensorService;

/**
 * Created by meghnavaidya on 3/7/18.
 */

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import com.example.elizabethli.mushpuppiestest.StepDetector;
import com.example.elizabethli.mushpuppiestest.stepInterface.StepListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;

@SuppressLint("Registered")
public class SensorService extends Service implements SensorEventListener, StepListener {

    private Sensor mStepDetectorSensor;
    private StepDetector simpleStepDetector;
    private SensorManager sensorManager;
    private Sensor accelerometer_sensor;
    private int step_count = 0;
    private long time_stamp;
    private int prefKey = 0;
    private IntentFilter intentFilter;
    private Handler handler;
    private int iteration_count = 0;
    private String current_Date;
    private String new_Date;
    private static Timer timer;
    private final IBinder mBinder = new LocalBinder();
    private String sensorType;

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onCreate() {
        Log.d("On create","On create");
        timer = new Timer();
        super.onCreate();
        Log.d("service started","service started");
        current_Date = getCurrentSystemDate();

        intentFilter = new IntentFilter();

        intentFilter.addAction("android.intent.action.TIME_SET");
        intentFilter.addAction("android.intent.action.TIME");
        intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
        intentFilter.addAction("android.intent.action.TIME_TICK");

        getApplication().registerReceiver(dateChangedReceiver, intentFilter);

        if (iteration_count != 0) {
            prefKey = iteration_count;
        }

        initSensor();

    }

    /**
     * Class used for the client Binder.  Because we know this service always
     * runs in the same process as its clients, we don't need to deal with IPC.
     */
    public class LocalBinder extends Binder {
        SensorService getService() {
            // Return this instance of LocalService so clients can call public methods
            return SensorService.this;
        }
    }

    /**
     * Gets current date to be able to get daily things
     * @return - date format
     */
    private String getCurrentSystemDate() {

        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        return df.format(c.getTime());
    }

    /**
     * Gets sensors to be able to detect if the accelerometer is running and if the pedometer is present.
     */
    private void initSensor() {

        SensorManager mSensorManager = (SensorManager)
                this.getSystemService(Context.SENSOR_SERVICE);
        assert mSensorManager != null;
        if (mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null) {
            sensorType = "Pedo";
            //isSensorPresent = true;
            Toast.makeText(SensorService.this,"Pedometer Sensor Present",Toast.LENGTH_SHORT).show();
            mStepDetectorSensor =
                    mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
            mSensorManager.registerListener(this, mStepDetectorSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }else {
            sensorType = "Accelo";
            Toast.makeText(SensorService.this, "Accelerometer Sensor Present", Toast.LENGTH_SHORT).show();
            sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            accelerometer_sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sensorManager.registerListener(this, accelerometer_sensor, SensorManager.SENSOR_DELAY_GAME);

            simpleStepDetector = new StepDetector();
            simpleStepDetector.registerListener(this);
        }
    }

    /**
     * Used to be able to receive new dates for new days and then be able to use that in other methods
     */
    private final BroadcastReceiver dateChangedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (action.equals("android.intent.action.TIME_SET") ||
                    action.equals("android.intent.action.TIMEZONE_CHANGED") ||
                    action.equals("android.intent.action.TIME") ||
                    action.equalsIgnoreCase("android.intent.action.TIME_TICK")) {

                new_Date = getCurrentSystemDate();
                if(!current_Date.equalsIgnoreCase(new_Date)){
                    current_Date = new_Date;
                    step_count = 0;
                    prefKey = 0;
                    iteration_count = 0;
                    PreferenceManager.getDefaultSharedPreferences(SensorService.this).edit().clear().apply();

                }

            }
        }
    };


    @Override
    public void onDestroy() {
        getApplication().unregisterReceiver(dateChangedReceiver);
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        return Service.START_STICKY;
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {

            simpleStepDetector.updateAccel(
                    event.timestamp, event.values[0], event.values[1], event.values[2]);



        }else if(event.sensor.getType()==Sensor.TYPE_STEP_DETECTOR){
            int  countOnResume = (int) event.values[0];
            step_count++;
            Log.d("Steps working","steps working");
            try{

                DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.ENGLISH);
                Calendar calobjendTime = Calendar.getInstance();
                String endTime = df.format(calobjendTime.getTime());

                Date dateEntTime = df.parse(endTime);
                Calendar calObjStartTime = Calendar.getInstance();
                calObjStartTime.setTime(df.parse(endTime));
                calObjStartTime.add(Calendar.MINUTE,-1);
                String startTime = df.format(calObjStartTime.getTime());
                Log.d("StartTime"+startTime,"EndTime"+endTime);



            }catch (Exception e){

                e.printStackTrace();
            }

        }
    }


    @Override
    public void step(long timeNs) {
        step_count++;
        Log.d("Steps working","steps working");
        try{

            DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.ENGLISH);
            Calendar calobjendTime = Calendar.getInstance();
            String endTime = df.format(calobjendTime.getTime());

            Date dateEntTime = df.parse(endTime);
            Calendar calObjStartTime = Calendar.getInstance();
            calObjStartTime.setTime(df.parse(endTime));
            calObjStartTime.add(Calendar.MINUTE,-1);
            String startTime = df.format(calObjStartTime.getTime());
            Log.d("StartTime"+startTime,"EndTime"+endTime);



        }catch (Exception e){

            e.printStackTrace();
        }
    }


    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Log.d("Tak Removed","Removed");
        super.onTaskRemoved(rootIntent);
        Intent restartServiceIntent = new Intent(getApplicationContext(), this.getClass());
        restartServiceIntent.setPackage(getPackageName());

        PendingIntent restartServicePendingIntent = PendingIntent.getService(getApplicationContext(), 1, restartServiceIntent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmService = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmService.set(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + 1000,
                restartServicePendingIntent);

    }

}
