package org.springframework.samples.mush.createApp.MushPuppies.User;

import java.util.ArrayList;
import java.util.Arrays;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 
 * This Goals Controller manages the mapping and handling of crud processes for the goals database table
 * 
 * @author Nathan Oran
 * @author Christian Hernandez
 * @author Justin Lee
 *
 */
@RestController
public class GoalsController {
	
	@Autowired
	private GoalRepository goalRepo;
	
	@Autowired
	//private UserRepository userRepository;
	
	//private final Logger logger = LoggerFactory.getLogger(GoalsController.class);
	
	/**
	 * This Get method returns a list of all the goals of all the users
	 * @return
	 */
	@GetMapping(path = "/allgoals")
	public @ResponseBody Iterable<Goals> getAllGoals()
	{
		return goalRepo.findAll();
	}
	
	/**
	 * Saves a new goal for a specific user
	 * 
	 * @param uid - id of the user who created a new goal
	 * @param goal - new goal string that the user wants to save
	 * @return
	 */
	@PostMapping(path = "/addGoal")
	public @ResponseBody String addNewGoal (@RequestBody Map<String, Object> map)
	{
		int uid = (int) map.get("uid");
		String goal = (String) map.get("goal");
		
		Goals test = new Goals(uid, goal);
		test.setGoal(goal);
		
		goalRepo.save(test);
		return "Saved";
	}

	
	@RequestMapping(path = "/goaldelete", method = RequestMethod.POST)
	public @ResponseBody Map<String, String> deleteGoal(@RequestBody Map<String, Object> map)
	{
		Map<String, String> response = new HashMap<String, String>();
		
		int uid = (int) map.get("uid");
		String goal = (String) map.get("goal");
		if(goalRepo.existsByUidAndGoal(uid, goal)) {
			goalRepo.delete(goalRepo.findByUidAndGoal(uid, goal));
			response.put("deletemessage", "Goal Deleted");
		} else
			response.put("deletemessage", "That Goal does not Exist");
		return response;
	}
	

	@PostMapping(path = "/getgoals")
	public @ResponseBody Map<String,Object> loginGoals(@RequestBody Map<String, Object> map){
		List<Goals> goals = new ArrayList<>();
		int uid = (int) map.get("uid");
		Map<String, Object> response = new HashMap<String, Object>();
		
		goalRepo.findAllByUid(uid).forEach(goals::add);
		response.put("goals", goals);
		return response;
	}

	//Controller to Update Goals
	@RequestMapping(method = RequestMethod.POST, path = "/updategoal")
	public @ResponseBody Map<String, String> updateGoal(@RequestBody Map<String, Object> map)
	{
		int goalsid = (int) map.get("goalsId"); 
		String goalString = (String) map.get("goal");
		Map<String, String> response = new HashMap<String, String>();
		
		if(goalRepo.existsById(goalsid))
		{
			Goals goal = goalRepo.findByGoalsId(goalsid);
			goal.updateGoal(goalString);
			response.put("success", "true");
		}
		else
		{
			response.put("success", "false");
		}
		return response;
	}
	
	
	@RequestMapping(path = "/goalcomplete", method = RequestMethod.POST )
	public @ResponseBody String completeGoal(@RequestBody Map<String, Object> map)
	{
		int goalsid = (int) map.get("goalsId");
		Goals goal;
		goal = goalRepo.findByGoalsId(goalsid);
		goal.setComplete(1);
		goalRepo.save(goal);
		return "Goal is completed";
	}
}