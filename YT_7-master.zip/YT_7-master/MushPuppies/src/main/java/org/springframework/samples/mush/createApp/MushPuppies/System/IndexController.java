package org.springframework.samples.mush.createApp.MushPuppies.System;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Method for more error handling
 * This was done as I was going off of the PetClinic examples and other templates
 * @author Christian Hernandez
 *
 */
@Controller
public class IndexController {

	private static final String PATH = "/error";

	/**
	 * Method to catch a string error
	 * More work still has to be done to us
	 * @return a string
	 */
    @GetMapping("/error")
    public String error() {
        return "Error handling";
    }

    
}
