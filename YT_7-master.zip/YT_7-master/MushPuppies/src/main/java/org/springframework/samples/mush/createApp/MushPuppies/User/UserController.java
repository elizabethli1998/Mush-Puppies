package org.springframework.samples.mush.createApp.MushPuppies.User;

import java.util.ArrayList;
import java.util.Arrays;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 
 * This User Controller manages the mapping and handling of crud processes for
 * the user database table
 * 
 * @author nathanoran
 * @author christianhernandez
 * @author justinlee
 *
 */
@RestController
public class UserController {

	@Autowired
	UserRepository userRepo;

	@Autowired
	ExerciseRepository exerciseRepo;
	
	@Autowired
	GoalRepository goalsRepo;
	
	@Autowired
	DailyLogRepository dailyLogRepo;
	
	@Autowired
	FriendsRepository friendsRepo;
	
	private final Logger logger = LoggerFactory.getLogger(UserController.class);

	/**
	 * This POST method is the login process for our application.
	 * 
	 * It takes the username and password attempt, then it checks if a user exists
	 * that has that username. if no user exists with that name, it returns an
	 * object with a boolean object named success set to false and a corresponding
	 * message.
	 * 
	 * If the user exists, the user's password is compared to that of the one
	 * entered in the method call. if the passwords are not the same, it returns an
	 * object with a boolean object named success set to false and a corresponding
	 * message.
	 * 
	 * Once the user and password have been confirmed, the method returns and JSON
	 * Object with success set to true and the user's id.
	 * 
	 * @param username
	 *            -
	 * @param password
	 * @return If no user exists with that name or if the user's password doesn't
	 *         match the one given, it returns an object with a boolean object named
	 *         success set to false and a corresponding message. Otherwise, the
	 *         object's success set to true and includes the user's id.
	 */
	// http://localhost:8080/login/cah1/hi
	// Create a method that will return the id if the username and passwords match
	@RequestMapping(method = RequestMethod.POST, path = "login")
	public @ResponseBody Map<String, Object> login(@RequestBody Map<String,String> login) {
		User user = new User(); 

		Map<String, Object> response = new HashMap<String, Object>();

		if (userRepo.existsByUsername(login.get("username"))) {

			user = userRepo.findByUsername(login.get("username"));

			if (user.getPassword().equals(login.get("password"))) {
				response.put("success", "true");
				user.includeJSON(response);
			} else {
				response.put("success", "false");
				response.put("message", "That password is incorrect");
			}
		} else {
			response.put("success", "false");
			response.put("message", "That username is not registered");
		}

		return response;

	}

	// http://localhost:8080/register
	/**
	 * This is the POST implementation of the the saveUser Method.
	 * 
	 * It assumes that the received RequestBody contains all of the necessary
	 * parameters for a new user in the users table. Then it checks if the username
	 * of the submitted user is not shared with any other user and saves the new
	 * user.
	 * 
	 * @param newUser
	 *            User object that contains all the desired user data
	 * @return JSON Object with success set to true if the user was successfully
	 *         saved and false if not. The user ID is also returned on a success. On
	 *         fails, a String "message" is returned explaining the error.
	 */
	@PostMapping(path = "/register")
	public @ResponseBody Map<String, Object> addNewUser(@RequestBody User newUser) {
		Map<String, Object> response = new HashMap<String, Object>();

		if (userRepo.existsByUsername(newUser.getUsername())) {
			response.put("success", "false");
			response.put("message", "Username not available.");
		} else {
			newUser = userRepo.save(newUser);
			response.put("success", "true");
			response.put("uid", newUser.getUid());
		}

		return response;
	}

	/**
	 * This GET method takes all the necessary user data and creates a new user
	 * object that is then saved into the database
	 * 
	 * @author nathanoran
	 * 
	 * @param username
	 *            String that defines the new user's username
	 * @param password
	 *            String that defines the new user's password
	 * @param firstname
	 *            String the defines the new user's first name
	 * @param lastname
	 *            String the defines the user's last name
	 * @param age
	 *            int that defines the user's age in years
	 * @param height
	 *            int that defines the user's height in inches
	 * @param weight
	 *            int that defines the user's weight in pounds
	 * @return returns a JSON Object with two parameters: first, a boolean called
	 *         success set to true if the user was successfully registered, and
	 *         false if the user was not registered for whatever reason. Second, if
	 *         the success is true, it returns the new user's id. If the success is
	 *         false there is a string message that details why they were not
	 *         successfully registered.
	 */
	@RequestMapping(method = RequestMethod.POST, path = "/updateuser")
	public @ResponseBody Map<String, String> updateUser(@RequestBody Map<String, Object> map) {
		Map<String, String> response = new HashMap<String, String>();

		int uid = (int) map.get("uid");
		String username = (String) map.get("username");
		String firstname = (String) map.get("firstname");
		String lastname = (String) map.get("lastname");
		int age = (int) map.get("age");
		int height = (int) map.get("height"); 
		int weight = (int) map.get("weight");
		
		if (userRepo.existsByUid(uid)) {
			User user = userRepo.findByUid(uid);
			user.updateUser(username, firstname, lastname, age, height, weight);
			userRepo.save(user);
			response.put("success", "true");
		} else {
			response.put("success", "false");
		}

		return response;

	}

	@RequestMapping(method = RequestMethod.GET, path = "/allusers")
	public List<User> getAllUsers() {
		List<User> users = new ArrayList<>();
		userRepo.findAllByUidGreaterThanOrderByTotalstepsDesc(0).forEach(users::add);
		return users;
	}

	@RequestMapping(path = "/userdelete", method = RequestMethod.POST)
	public @ResponseBody String deleteUser(@RequestBody Map<String, Object> map) {
		int uid = (int) map.get("uid");
		if (userRepo.existsByUid(uid)) {
			Collection<Goals> toDeleteGoals = goalsRepo.findAllByUid(uid);
			for(Goals g : toDeleteGoals) {
				goalsRepo.delete(g);
			}
			Iterable<Exercise> toDeleteExercises = exerciseRepo.findAllByUid(uid);
			for(Exercise e : toDeleteExercises) {
				exerciseRepo.delete(e);
			}
			Iterable<DailyLog> toDeleteLogs = dailyLogRepo.findAllByUid(uid);
			for(DailyLog d : toDeleteLogs) {
				dailyLogRepo.delete(d);
			}
			Iterable<Friends> toDeleteFriends = friendsRepo.findAllByUid1OrUid2(uid, uid);
			for(Friends f : toDeleteFriends) {
				friendsRepo.delete(f);
			}
			userRepo.deleteById(uid);
			return "Deleted User";
		} else
			return "No User Exsists By that Id";
	}

}
