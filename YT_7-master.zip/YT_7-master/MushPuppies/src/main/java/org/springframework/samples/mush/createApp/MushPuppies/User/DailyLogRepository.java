package org.springframework.samples.mush.createApp.MushPuppies.User;
import java.util.Collection;


//import org.jboss.logging.Param;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;



@Repository
public interface DailyLogRepository extends CrudRepository<DailyLog, Integer> {

	public Collection<DailyLog> findAll();
	public DailyLog findByUidAndDate(@Param("uid") int uid,@Param("date") String date);
	public Boolean existsByUidInAndDateIn(@Param("uid") int uid,@Param("date") String date);
	public Iterable<DailyLog> findAllByUid(@Param("uid") int uid);
	public void deleteAllByUid(@Param("uid") int uid);
	public Collection<DailyLog> findLast7ByUid(@Param("uid") int uid);
}
