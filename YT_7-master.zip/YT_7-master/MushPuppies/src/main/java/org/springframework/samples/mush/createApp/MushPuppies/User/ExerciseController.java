package org.springframework.samples.mush.createApp.MushPuppies.User;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;


import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



/**
 * This is a controller class for the Exercise table
 * 
 * @author Christian Hernandez
 * @author Nathan Oran
 * @author Justin Lee
 */
@RestController
public class ExerciseController {

	/**
	 * Exercise Repository
	 */
	@Autowired
	private ExerciseRepository exerciseRepo;
	
	//@Autowired UserRepository userRepo;
	
	/**
	 * Deletes an exercise
	 * @param id of the exercise
	 * @return a string that says the exercise is deleted
	 */
	@RequestMapping(path = "/exerciseDeleteID", method = RequestMethod.POST)
	public @ResponseBody String deleteExercise (@RequestBody Map<String, Object> map)
	{
		int id = (int) map.get("exerciseid");
		
		if(exerciseRepo.existsById(id)) {
			exerciseRepo.deleteById(id);
			return "Deleted Exercise";
		} else
			return "Failed";
		
	}
	
	/**
	 * Adds a new exercise to the table
	 * @param exerciseName 
	 * @return "Added new exercise" string
	 */
	@PostMapping(path = "/addexercise")
	public @ResponseBody Exercise addNewExercise(@RequestBody Exercise ex)
	{
		ex = exerciseRepo.save(ex);
		return ex;
	}
	
	@GetMapping(path = "/exercisesonlogin/{uid}")
	public @ResponseBody List<Exercise> loginExercises(@PathVariable int uid){
		List<Exercise> exercises = new ArrayList<>();
		exerciseRepo.findAllByUid(uid).forEach(exercises::add);
		return exercises;
	}
	
	@RequestMapping(path = "/deleteexerciseuid", method = RequestMethod.POST)
	public @ResponseBody String deleteUIDsExercise(@RequestBody Map<String, Object> map)
	{
		int id = (int)map.get("uid");
		if(exerciseRepo.existsByUid(id))
		{
			Iterable<Exercise> toDelete = exerciseRepo.findAllByUid(id);
			for(Exercise e : toDelete) {
				exerciseRepo.delete(e);
			}
			return "Deleted all exercises for" + id + ".";
		}
		else
		{
			return "The uid did not have any exercises";
		}
		
	}
	
}
