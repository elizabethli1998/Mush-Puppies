package org.springframework.samples.mush.createApp.MushPuppies.User;
import java.util.ArrayList;
import java.util.Arrays;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;


import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DailyLogController {

	@Autowired
	DailyLogRepository dailyLogRepo;
	
	@Autowired
	UserRepository userRepo;
	
	@RequestMapping(path = "/alldailylog", method = RequestMethod.GET)
	public @ResponseBody Collection<DailyLog> getAllDailyLog()
	{
		return dailyLogRepo.findAll();
	}
	
	@RequestMapping(path = "/logcalories", method = RequestMethod.POST)
	public @ResponseBody String addCaloriesLog(@RequestBody Map<String, Object> map)
	{
		DailyLog dailyLog;
		User user;
		
		int uid = (int) map.get("uid");
		int dailycalories = (int) map.get("dailycalories");
		int totalcalories = (int) map.get("totalcalories");
		String date = (String) map.get("date");
		
		if(userRepo.existsByUid(uid))
			user = userRepo.findByUid(uid);
		else
			return "How the h*ck did you screw this up?";
		
		if(dailyLogRepo.existsByUidInAndDateIn(uid, date)) {
			dailyLog = dailyLogRepo.findByUidAndDate(uid, date); 
			dailyLog.setDailyCalories(dailycalories);
		} else {
			dailyLog = new DailyLog(uid, date, 0, dailycalories);
		}
		
		user.setTotalcalories(totalcalories);
		
		dailyLogRepo.save(dailyLog);
		userRepo.save(user);
		return "nice";
	}
	
	@RequestMapping(path = "/logsteps", method = RequestMethod.POST)
	public @ResponseBody String addStepsLog(@RequestBody Map<String, Object> map)
	{
		DailyLog dailyLog;
		User user;
		
		int uid = (int) map.get("uid");
		int dailysteps = (int) map.get("dailysteps");
		int totalsteps = (int) map.get("totalsteps");
		String date = (String) map.get("date");
		
		if(userRepo.existsByUid(uid))
			user = userRepo.findByUid(uid);
		else
			return "How the h*ck did you screw this up?";
		
		if(dailyLogRepo.existsByUidInAndDateIn(uid, date)) {
			dailyLog = dailyLogRepo.findByUidAndDate(uid, date); 
			dailyLog.setDailySteps(dailysteps);
		} else {
			dailyLog = new DailyLog(uid, date, dailysteps, 0);
		}
		
		user.setTotalsteps(totalsteps);
		
		dailyLogRepo.save(dailyLog);
		userRepo.save(user);
		return "nice";
	}
	
	@GetMapping(path = "/dailylogsonlogin/{uid}")
	public @ResponseBody List<DailyLog> loginDailyLogs(@PathVariable int uid){
		List<DailyLog> dailylogs = new ArrayList<>();		
		dailyLogRepo.findAllByUid(uid).forEach(dailylogs::add);
		return dailylogs;
	}
	
	@RequestMapping(path = "/myweek")
	public @ResponseBody Map<String, Object> weekLog(@RequestBody Map<String, Object> map)
	{
		List<DailyLog> dailylogs = new ArrayList<>();
		
		Map<String, Object> response = new HashMap<String, Object>();
 		
		int uid = (int) map.get("uid");
		
		dailyLogRepo.findLast7ByUid(uid).forEach(dailylogs::add);
		
		response.put("dailylogs", dailylogs);
		
		return response;
	}
}
