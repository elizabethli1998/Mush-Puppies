package org.springframework.samples.mush.createApp.MushPuppies.User;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.springframework.core.style.ToStringCreator;

/**
 * Class to have access to the goals table
 * @author Christian Hernandez
 * @author Justin Lee
 * @author Nathan Oran
 *
 */

@Entity
@Table(name = "goals")
public class Goals {
	/**
	 * Empty Goal constructor
	 */
	public Goals() {
		
	}
	
	/**
	 * Constructor to create a Goal object
	 * @param id of user
	 * @param goal
	 */
	public Goals(int uid, String goal) {
		this.uid = uid;
		this.goal = goal;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JoinColumn(name = "goalsId")
	private int goalsId;
	



	/**
	 * Id of user
	 */
	@JoinColumn(name = "uid")
	private int uid;
	
	/**
	 * Variable for goal
	 */
	@JoinColumn(name = "goal")
	private String goal;

	@JoinColumn(name = "complete")
	private int complete;
	
	
	public int getGoalsId() {
		return goalsId;
	}

	public void setGoalsId(int goalsId) {
		this.goalsId = goalsId;
	}

	
	
	/**
	 * Method to set id of user
	 * @param id
	 */
	public void setUid(int uid) {
		this.uid = uid;
	}
	
	public int getUID()
	{
		return this.uid;
	}
	
	/**
	 * Method to get the goal
	 * @return
	 */
	public String getGoal() {
			return goal;
	}
	
	/**
	 * Method to set goal
	 * @param goal
	 */
	public void setGoal(String goal) {
		this.goal = goal;
	}
	
	public int getComplete()
	{
		return this.complete;
	}
	
	public void setComplete(int complete)
	{
		this.complete = complete;
	}
	
public void updateGoal(String goal)
{
	this.setGoal(goal);
}
	
	@Override
	public String toString()
	{
		return new ToStringCreator(this)
				.append("goalsId", this.getGoalsId())
				.append("uid", this.getUID())
				.append("goal", this.getGoal())
				.append("complete", this.getComplete()).toString();
				
	}

}
