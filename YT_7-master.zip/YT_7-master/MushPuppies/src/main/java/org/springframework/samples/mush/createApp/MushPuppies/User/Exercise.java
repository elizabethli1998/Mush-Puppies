package org.springframework.samples.mush.createApp.MushPuppies.User;

/**
 * This is the class for Exercises
 * @author Christian Hernandez
 *
 */

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.springframework.core.style.ToStringCreator;

import java.sql.Date;

/**
 * Class to focus on the Exercise entity
 * 
 * @Entity
 * @Table Exercise Table
 *
 */

@Entity
@Table(name = "exercise")
public class Exercise {

	public Exercise() {

	}

	/**
	 * Exercise constructor
	 * 
	 * @param id
	 * @param exerciseName
	 */
	public Exercise(int uid, int androidId, String date) {
		this.uid = uid;
		this.androidId = androidId;
		this.date = date;
	}
	
	/**
	 * id for the exercise table.
	 */
	@Id
	@JoinColumn(name = "exerciseId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int exerciseId;

	/**
	 * This is the user's id. This id is a foreign key.
	 */
	@JoinColumn(name = "uid")
	private int uid;

	/**
	 * Variable for name of exercise. Also, this is showing the name of the exercise
	 * table
	 */
	@JoinColumn(name = "androidId")
	private int androidId;

	/**
	 * this is the date the the user completed the exercise
	 */
	@JoinColumn(name = "date")
	private String date;

	public int getExerciseId() {
		return exerciseId;
	}

	public void setExerciseId(int exerciseId) {
		this.exerciseId = exerciseId;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public int getAndroidId() {
		return androidId;
	}

	public void setAndroidId(int androidId) {
		this.androidId = androidId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
}
