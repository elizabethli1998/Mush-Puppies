package org.springframework.samples.mush.createApp.MushPuppies.User;

import java.util.Collection;



import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
/**
 * Repository for Goal Controller
 * @author Christian Hernandez
 * @author Nathan Oran
 * @author Justin Lee
 */
@Repository
public interface GoalRepository extends CrudRepository<Goals, Integer> {
	
	/**
	 * Method to get all goals
	 */
	Collection<Goals> findAll();
	
	/**
	 * Method to find a specific goal
	 * @param id of user
	 * @return goal
	 */

	//swag420
	//Collection<Goals> findById(@Param("goalsId") goalsId);

	Collection<Goals> findAllByUid(@Param("uid") int uid);
	public Goals findByGoalsId(@Param("goalsid")int goalsid);
	public boolean existsByGoalsId(@Param("goalsid") int goalsid);
	public void deleteAllByUid(@Param("uid") int uid);
	public boolean existsByUidAndGoal(@Param("uid")int uid, @Param("goal")String goal);
	public Goals findByUidAndGoal(@Param("uid")int uid, @Param("goal")String goal);

}
