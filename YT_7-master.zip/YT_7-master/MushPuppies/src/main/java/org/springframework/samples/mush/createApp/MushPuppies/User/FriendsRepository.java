package org.springframework.samples.mush.createApp.MushPuppies.User;



import java.util.Collection;
//import org.jboss.logging.Param;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository for Friends 
 * @author Christian Hernandez
 * @author Nathan Oran
 * @author Justin Lee
 *
 */

@Repository
public interface FriendsRepository extends CrudRepository<Friends, Integer>{

	/**
	 * Method to final everything in the friends table
	 */
	Collection<Friends> findAll();
	/**
	 * Method to find a specific friend
	 * @param fid 
	 * @return the friend corresponding to that specific id
	 */
	//Collection<Friends> findById(@Param("fid") int fid);
	
	/**
	 * Returns the row corresponding to the user's id
	 * @param uid of the user
	 * @return row correspoding to the userid
	 */
	//Friends findByUid(@Param("uid") int uid);
	/**
	 * Method to save the friend's object
	 */
	public Friends findByFriendsId(@Param("friendsId") int friendsid);
	
	public Iterable<Friends> findAllByUid1OrUid2(@Param("uid1")int uid1, @Param("uid2")int uid2);
	
	/**
	 * Delete a friend based on the userid
	 * @param uid
	 */
	void deleteByFriendsId(@Param("friendsId")int friendsId);
	
	public Collection<Friends> findAllByUid2AndStatus(@Param("uid2")int uid2, @Param("status")int status);
	public Collection<Friends> findAllByUid1AndStatus(@Param("uid1")int uid1,@Param("status") int status);
	public Friends findByUid1AndUid2AndStatus(@Param("uid1")int uid1, @Param("uid2")int uid2, @Param("status")int i);
}
