package org.springframework.samples.mush.createApp.MushPuppies.User;


import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * 
 * Repository for users
 * 
 * @author nathanoran
 * @author christianhernandez
 *
 */
@Repository
public interface UserRepository extends CrudRepository<User, Integer> {
	
	public User findByUsername(@Param("username") String username);
	public User findByUid(@Param("uid") int uid);
	public void deleteByUid(@Param("uid") int uid);
	public Boolean existsByUid(@Param("uid") int uid);
	public Boolean existsByUsername(@Param("username") String username);
	public Iterable<User> findAllByUidGreaterThanOrderByTotalstepsDesc(@Param("uid")int uid);
}
