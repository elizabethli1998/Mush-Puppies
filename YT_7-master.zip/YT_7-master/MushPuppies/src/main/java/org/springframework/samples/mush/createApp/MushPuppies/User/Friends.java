package org.springframework.samples.mush.createApp.MushPuppies.User;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.springframework.core.style.ToStringCreator;

/**
 * Class to define the Friends entity
 * 
 * @author Christian Hernandez
 * @author Nathan Oran
 * @author Justin Lee
 */
@Entity
@Table(name = "friends")
public class Friends {

	/**
	 * Empty constructor for Friends
	 */
	public Friends()
	{
		
	}
	
	/**
	 * Constructor to create a Friends object
	 * @param fid id for a Friend
	 * @param uid id for a user
	 * @param status to display whether they accepted
	 */
	public Friends(int uid1, int uid2)
	{

		super();

		this.uid1 = uid1;
		this.uid2 = uid2;
		this.status = 0;
	}
	
	/**
	 * Friends id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "friendsId")
	private int friendsId;

	/**
	 * id for the first user
	 */
	@JoinColumn(name = "uid1")
	private int uid1;
	
	/**
	 * id for the first user
	 */
	@JoinColumn(name = "uid2")
	private int uid2;

	/**
	 * Status int to say whether they accepted a friend request
	 */
	@JoinColumn(name = "status")
	private int status;

	public int getFriendsId() {
		return friendsId;
	}

	public void setFriendsId(int friendsId) {
		this.friendsId = friendsId;
	}

	public int getUid1() {
		return uid1;
	}

	public void setUid1(int uid1) {
		this.uid1 = uid1;
	}

	public int getUid2() {
		return uid2;
	}

	public void setUid2(int uid2) {
		this.uid2 = uid2;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
	
	@Override
	public String toString()
	{
		return new ToStringCreator(this)
				.append("friendsId", this.getFriendsId())
				.append("uid1", this.getUid1())
				.append("uid2", this.getUid2())
				.append("status", this.getStatus()).toString();
	}
}

