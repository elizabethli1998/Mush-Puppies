package org.springframework.samples.mush.createApp.MushPuppies;



import java.io.IOException;

import org.springframework.boot.CommandLineRunner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.io.support.EncodedResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.samples.mush.createApp.MushPuppies.User.ProfileRepository;

import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * This class runs the Spring application
 * @author Christian Hernandez
 * @author Nathan Oran
 * @author Justin Lee
 */

@SpringBootApplication
public class App extends SpringBootServletInitializer 
{
	/**
	 * Runs the application
	 * @param args
	 */
    public static void main( String[] args )
    {
        SpringApplication.run(App.class, args);
    }
    
    

  }

