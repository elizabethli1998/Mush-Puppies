package org.springframework.samples.mush.createApp.MushPuppies.System;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * 
 * Controller to help prevent crashes
 * @author Christian Hernandez
 *
 */
@Controller
public class CrashController {
	
	/**
	 * Method to catch a runtime Exercption
	 * @throws RunTime Exception
	 * @return a message
	 */
	@GetMapping("/oups")
	public String triggerException()
	{
		throw new RuntimeException("Expected: controller used to showcase what happens when an excpetion is thrown");
	}
}