package org.springframework.samples.mush.createApp.MushPuppies.User;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.springframework.core.style.ToStringCreator;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * Class to define the User entity
 * 
 * @author Nathan Oran
 * @author Justin Lee
 * @author Christian Hernandez
 *
 */
@Entity
@Table(name = "users")
public class User {
	
	/**
	 * Creates an Empty User
	 */
	public User()
	{
		
	}
	
	/**
	 * Creates a new user object with the given parameters
	 * 
	 * @param username
	 * @param password
	 * @param firstname
	 * @param lastname
	 * @param age
	 * @param height
	 * @param weight
	 */
	public User(String username, String password, String firstname, String lastname,
			int age, int height, int weight)
	{
		this.setUsername(username);
		this.setPassword(password);
		this.setFirstname(firstname);
		this.setLastname(lastname);
		this.setAge(age);
		this.setHeight(height);
		this.setWeight(weight);
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "uid")
	private int uid;
	
	@JoinColumn(name = "username")
	private String username;
	
	@JoinColumn(name = "password")
	private String password;
	
	@JoinColumn(name = "firstname")
	private String firstname;
	
	@JoinColumn(name = "lastname")
	private String lastname;
	
	@JoinColumn(name = "age")
	private int age;
	
	@JoinColumn(name = "height")
	private int height;
	
	@JoinColumn(name = "weight")
	private int weight;
	
	@JoinColumn(name = "totalsteps")
	private int totalsteps;
	
	@JoinColumn(name = "totalcalories")
	private int totalcalories;
	
	@OneToMany
	@JoinColumn(name = "uid")
	private List<Exercise> exercises = new ArrayList<Exercise>();

	@OneToMany
	@JoinColumn(name = "uid")
	private List<Goals> goals = new ArrayList<Goals>();
	
	@OneToMany
	@JoinColumn(name = "uid")
	private List<DailyLog> dailylogs = new ArrayList<DailyLog>();

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getTotalsteps() {
		return totalsteps;
	}

	public void setTotalsteps(int totalsteps) {
		this.totalsteps = totalsteps;
	}

	public int getTotalcalories() {
		return totalcalories;
	}

	public void setTotalcalories(int totalcalories) {
		this.totalcalories = totalcalories;
	}

	
	public List<Exercise> getExercises() {
		return exercises;
	}

	public void setExercises(List<Exercise> exercises) {
		this.exercises = exercises;
	}

	public void addExercise(Exercise e) {
		this.exercises.add(e);
	}
	
	public void removeExercise(Exercise e) {
		this.exercises.remove(e);
	}
	
	public List<Goals> getGoals() {
		return goals;
	}

	public void setGoals(List<Goals> goals) {
		this.goals = goals;
	}

	public void addGoal(Goals g) {
		this.goals.add(g);
	}
	
	public void removeGoal(Goals g) {
		this.goals.remove(g);
	}
	
	public List<DailyLog> getDailylogs() {
		return dailylogs;
	}

	public void setDailylogs(List<DailyLog> dailylogs) {
		this.dailylogs = dailylogs;
	}
	
	public void addDailylog(DailyLog d) {
		this.dailylogs.add(d);
	}
	
	public void removeDailylog(DailyLog d) {
		this.dailylogs.remove(d);
	}
	
	
	/**
	 * Updates this user object with the given parameters - used to update a profile
	 * 
	 * @param username
	 * @param password
	 * @param firstname
	 * @param lastname
	 * @param age
	 * @param height
	 * @param weight
	 */
	public void updateUser(String username, String firstname, String lastname,
			int age, int height, int weight)
	{
		this.setUsername(username);
		this.setFirstname(firstname);
		this.setLastname(lastname);
		this.setAge(age);
		this.setHeight(height);
		this.setWeight(weight);
	}
	
	@Override
	public String toString()
	{
		return new ToStringCreator(this)
				.append("id", this.getUid())
				.append("username", this.getUsername())
				.append("password", this.getPassword())
				.append("firstname", this.getFirstname())
				.append("lastname", this.getLastname())
				.append("age", this.getAge())
				.append("height", this.getHeight())
				.append("weight", this.getWeight())
				.toString();
	}
	
	public void includeJSON(Map<String, Object> map) {
		map.put("uid", this.getUid());
		map.put("username", this.getUsername());
		map.put("password", this.getPassword());
		map.put("firstname", this.getFirstname());
		map.put("lastname", this.getLastname());
		map.put("age", this.getAge());
		map.put("height", this.getHeight());
		map.put("weight", this.getWeight());
		map.put("totalsteps", this.getTotalsteps());
		map.put("totalcalories", this.getTotalcalories());
		map.put("exercises", this.getExercises());
		map.put("goals", this.getGoals());
		map.put("dailylogs", this.getDailylogs());
	}
	
	
}
