package org.springframework.samples.mush.createApp.MushPuppies.User;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.springframework.core.style.ToStringCreator;

import net.bytebuddy.asm.Advice.This;

import java.util.Date;

@Entity
@Table(name = "dailylog")
public class DailyLog {

	public DailyLog() {
	}

	public DailyLog(int uid, String date, int dailysteps, int dailycalories) {
		super();
		this.uid = uid;
		this.date = date;
		this.dailysteps = dailysteps;
		this.dailycalories = dailycalories;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "dailylogId")
	private int dailylogId;

	@JoinColumn(name = "uid")
	private int uid;

	@JoinColumn(name = "date")
	private String date;

	@JoinColumn(name = "dailysteps")
	private int dailysteps;

	@JoinColumn(name = "dailycalories")
	private int dailycalories;

	public int getDailyLogID()

	{
		return this.dailylogId;
	}

	public void setId(int dailylogId) {
		this.dailylogId = dailylogId;
	}

	public int getUID() {
		return this.uid;
	}

	public void setUID(int uid) {
		this.uid = uid;
	}

	public String getDate() {
		return this.date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getDailySteps() {
		return this.dailysteps;
	}

	public void setDailySteps(int dailysteps) {
		this.dailysteps = dailysteps;
	}

	public int getDailyCalories() {
		return this.dailycalories;
	}

	public void setDailyCalories(int dailycalories) {
		this.dailycalories = dailycalories;
	}

	@Override
	public String toString() {
		return new ToStringCreator(this).append("dailylogId", this.getDailyLogID()).append("uid", this.getUID())
				.append("date", this.getDate()).append("dailysteps", this.getDailySteps())
				.append("dailycalories", this.getDailyCalories()).toString();
	}

}
