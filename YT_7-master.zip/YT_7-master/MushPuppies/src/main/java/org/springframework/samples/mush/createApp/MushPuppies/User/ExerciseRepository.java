package org.springframework.samples.mush.createApp.MushPuppies.User;


import java.util.Collection;


//import org.jboss.logging.Param;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository for the exercises
 * @author Christian Hernandez
 *
 */
@Repository
public interface ExerciseRepository extends CrudRepository<Exercise, Integer>{
	
	/**
	 * Method to find all the exercises
	 */
	public Collection<Exercise> findAll();
	/**
	 * Deletes an exercise
	 * @param id of exercise
	 */
	public void deleteByExerciseId(@Param("exeriseId")Integer exerciseId);
	
	public Iterable<Exercise> findAllByUid(@Param("uid") Integer uid);
	public void deleteByUid(@Param("uid") int uid);
	public boolean existsByUid(int id);
}
