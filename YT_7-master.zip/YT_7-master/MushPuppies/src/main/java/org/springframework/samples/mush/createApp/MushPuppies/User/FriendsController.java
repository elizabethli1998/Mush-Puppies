package org.springframework.samples.mush.createApp.MushPuppies.User;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
/**
 * Controller class for Friends 
 *@author Christian Hernandez
 *@author Nathan Oran
 *@author Justin Lee
 */


@RestController
public class FriendsController {

	
	/**
	 * friendsRepo used to call methods from the Friend's repository
	 */
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private FriendsRepository friendsRepo;
	
	/**
	 * Method to get all the friends in the database table
	 * @return a Json object of all the friends
	 */
	@GetMapping(path = "/allfriends")
	public @ResponseBody Iterable<Friends> getAllFriends()
	{
		return friendsRepo.findAll();
	}
	
	
	/**
	 * Method to update the friend's table
	 * @param fid friend's id
	 * @param uid user id
	 * @param status of whether they are going to accepted a friend
	 * @return "Updated Friend" string to say whether it was a success
	 */
	@RequestMapping(path = "/updatefriends", method = RequestMethod.POST)
	public @ResponseBody String updateFriends(@RequestParam int fid,
			@RequestParam int uid, @RequestParam int status)
	
	{
		Friends friends = new Friends();
		//friends.setUID(uid);
		//friends.setStatus(status);
		return "Updated Friend";
	}
	
	/**
	 * Creating friend request
	 * @param map
	 * @return
	 */
	@RequestMapping(path = "/addfriend", method = RequestMethod.POST)
	public @ResponseBody Map<String, String> FriendRequest(@RequestBody Map<String, Object> map)
	{
		Map<String, String> response = new HashMap<String, String>();
		
		int uid1 = (int) map.get("uid");
		int uid2;
		
		String username = (String) map.get("username");
		if(userRepo.existsByUsername(username))
		{
			Friends friends = new Friends(uid1, userRepo.findByUsername(username).getUid());
			friendsRepo.save(friends);
			response.put("message", "The Request was sent");
		}
		else
		{
			response.put("message", "That user doesn't exist");
		}
		
		return response;
	}
	
	@RequestMapping(path = "/acceptfriend", method = RequestMethod.POST)
	public @ResponseBody void AcceptFriendRequest(@RequestBody Map<String, Object> map)
	{
		int uid2 = (int) map.get("uid");
		String username = (String) map.get("username");
		if(userRepo.existsByUsername(username)) {
			int uid1 = userRepo.findByUsername(username).getUid();
				
			Friends friend;
		
			friend = friendsRepo.findByUid1AndUid2AndStatus(uid1, uid2, 0);
		
			friend.setStatus(1);
			friendsRepo.save(friend);
		}
	}
	
	@RequestMapping(path = "/rejectfriend", method = RequestMethod.POST)
	public @ResponseBody void deleteRequest(@RequestBody Map<String, Object> map)
	{
		int uid2 = (int) map.get("uid");
		String username = (String) map.get("username");
		if(userRepo.existsByUsername(username)) {
			int uid1 = userRepo.findByUsername(username).getUid();
		
			Friends friend;
			
			friend = friendsRepo.findByUid1AndUid2AndStatus(uid1, uid2, 0);
		
			friendsRepo.delete(friend);
		}
	}
	
	@RequestMapping(path = "/myfriends", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> findMyFriends(@RequestBody Map<String, Object> map)
	{
		List<Friends> friendsObjects = new ArrayList<>();
		List<Username> usernames = new ArrayList<Username>();
		Map<String, Object> response = new HashMap<String, Object>();
		
		int uid = (int) map.get("uid");
		
		friendsRepo.findAllByUid1AndStatus(uid, 1).forEach(friendsObjects::add);
		for(Friends f : friendsObjects) {
			Username tempUsername = new Username();
			tempUsername.setUsername((userRepo.findByUid(f.getUid2()).getUsername()));
			usernames.add(tempUsername);
		}
			
		friendsObjects = new ArrayList<>();
		friendsRepo.findAllByUid2AndStatus(uid, 1).forEach(friendsObjects::add);
		for(Friends f : friendsObjects) {
			Username tempUsername = new Username();
			tempUsername.setUsername((userRepo.findByUid(f.getUid1()).getUsername()));
			usernames.add(tempUsername);
		}
		response.put("friends", usernames);
		return response;
	}
	
	@RequestMapping(path = "/myrequests", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> findMyFriendRequests(@RequestBody Map<String, Object> map)
	{
		List<Friends> friendsObjects = new ArrayList<>();
		List<Username> usernames = new ArrayList<Username>();
		Map<String, Object> response = new HashMap<String, Object>();

		int uid = (int) map.get("uid");
		
		friendsRepo.findAllByUid2AndStatus(uid, 0).forEach(friendsObjects::add);
		for(Friends f : friendsObjects) {
			Username tempUsername = new Username();
			tempUsername.setUsername((userRepo.findByUid(f.getUid1()).getUsername()));
			usernames.add(tempUsername);
		}
		response.put("requests", usernames);
		return response;
	}
	
	private class Username{
		private String username;

		Username(){}
		
		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}
	}
}
